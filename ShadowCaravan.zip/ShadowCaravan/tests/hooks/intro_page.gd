extends RefCounted
## Screenshot hook for the intro scene: page=0|1|2

func run(_tree: SceneTree, inst: Node) -> void:
	for s in OS.get_cmdline_user_args():
		var kv := s.split("=", true, 1)
		if kv.size() == 2 and kv[0] == "page":
			inst._go_page(int(kv[1]))
