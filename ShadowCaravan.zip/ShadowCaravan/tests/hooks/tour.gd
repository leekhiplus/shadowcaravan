extends RefCounted
## Screenshot hook: teleports the player / camera inside the game scene.
## args: pos=x,z  yaw=deg  pitch=rad  dist=metres  stage=n  solved=1  gate=1  fx=...

func run(tree: SceneTree, game: Node) -> void:
	var a := {}
	for s in OS.get_cmdline_user_args():
		var kv := s.split("=", true, 1)
		if kv.size() == 2:
			a[kv[0]] = kv[1]
	if a.has("stage"):
		GameState.quest_stage = int(a.stage)
		GameState.quest_changed.emit()
	if a.get("solved", "0") == "1":
		GameState.puzzle_solved = true
		game._refresh_world(false)
	if a.get("gate", "0") == "1":
		GameState.gate_open = true
		game._refresh_world(false)
	if a.has("pos"):
		var p := String(a.pos).split(",")
		var x := float(p[0])
		var z := float(p[1])
		var Terr := load("res://scripts/world/terrain.gd")
		var y: float = Terr.height_at(x, z) + float(a.get("dy", "0.3"))
		game.player.respawn(Vector3(x, y, z), deg_to_rad(float(a.get("yaw", "0"))))
		game.cam_rig.yaw = deg_to_rad(float(a.get("yaw", "0")))
	if a.has("pitch"):
		game.cam_rig.pitch = float(a.pitch)
	if a.has("dist"):
		game.cam_rig.distance = float(a.dist)
		game.cam_rig._cur_dist = float(a.dist)
	game.cam_rig.snap_to_target()
	if a.get("hidehud", "0") == "1":
		game.ui.hud.visible = false
		game.ui.touch.visible = false
	if a.has("wake"):
		if game.boss != null:
			game.boss._wake_up()
