extends SceneTree
## Headless gameplay smoke test. Boots the real game scene and drives the real game code:
## quest chain, rune puzzle, gate, combat, dodge i-frames, no-attack-through-walls, boss fight, relic,
## save / load / corruption recovery, pause, fast travel, death & respawn.
##
##   godot --headless --path . -s tests/smoke_playthrough.gd
##
## Prints PASS / FAIL lines and exits non-zero when anything fails. This is NOT a substitute for playing
## the game on a device; it verifies that the rules wired together in code behave as designed.

const Terrain := preload("res://scripts/world/terrain.gd")
const Items := preload("res://scripts/data/items.gd")

var EnemyScript: Variant

var GS: Variant
var CT: Variant
var RT: Variant
var game: Variant
var fails := 0
var passes := 0


func check(cond: bool, label: String) -> void:
	if cond:
		passes += 1
		print("  PASS  ", label)
	else:
		fails += 1
		print("  FAIL  ", label)


func frames(n: int) -> void:
	for i in n:
		await physics_frame


func secs(t: float) -> void:
	await create_timer(t).timeout


func _initialize() -> void:
	_run()


func _run() -> void:
	seed(12345)
	EnemyScript = load("res://scripts/world/enemy.gd")
	GS = root.get_node("GameState")
	CT = root.get_node("Controls")
	RT = root.get_node("Router")
	GS.save_path = "user://smoke_test_save.json"
	GS.delete_save()
	GS.new_game()
	var packed: PackedScene = load("res://scenes/game.tscn")
	game = packed.instantiate()
	root.add_child(game)
	current_scene = game
	await frames(5)

	print("== world & player")
	check(game.player != null and game.refs.has("gate"), "game scene builds world, player and refs")
	await frames(60)
	var gy: float = Terrain.height_at(game.player.global_position.x, game.player.global_position.z)
	check(game.player.is_on_floor(), "player stands on the terrain collider")
	check(absf(game.player.global_position.y - gy) < 0.6, "player height matches terrain height (%.2f vs %.2f)" % [game.player.global_position.y, gy])
	check(GS.objective_text().begins_with("Speak with Elder"), "stage 0 objective is to speak with the Elder")
	check(game.objective_distance() > 0.0 and game.objective_bearing() >= 0.0, "objective marker has distance and bearing")

	print("== quest start (Elder Sahir)")
	game._on_interact(game.refs.elder.node)
	check(game.ui.is_open("dialogue") and root.get_tree().paused, "dialogue opens and pauses the world")
	for i in 6:
		game.ui.panels.dialogue._advance()
	await frames(3)
	check(GS.quest_stage == 1, "accepting the quest moves to stage 1")
	check(not game.ui.is_modal_open() and not paused, "dialogue closes and the world resumes")

	print("== chest")
	var coins0: int = GS.coins
	game._on_interact(game.refs.chests["chest_camp"].node)
	check(GS.opened_ids.has("chest_camp") and GS.coins > coins0 and GS.count("healing_draught") >= 2, "chest grants coins and items once")
	var coins1: int = GS.coins
	game._on_interact(game.refs.chests["chest_camp"].node)
	check(GS.coins == coins1, "opened chest cannot be looted twice")

	print("== dodge roll invulnerability window")
	var P = game.player
	P.respawn(Vector3(-40, Terrain.height_at(-40, 45) + 0.3, 45))
	await frames(30)
	GS.hp = GS.max_hp()
	GS.stamina = GS.max_stamina()
	CT.touch_move = Vector2(0, -1)
	P._try_roll()
	var bad := 0
	var saw_inv := false
	var saw_vuln_after := false
	for i in 45:
		await physics_frame
		var t: float = P.roll_t
		if P.state == "roll":
			var inv: bool = P.is_invulnerable()
			if t < P.IFRAME_START - 0.001 and inv:
				bad += 1
			if t >= P.IFRAME_START + 0.02 and t <= P.IFRAME_END - 0.02:
				if not inv:
					bad += 1
				else:
					saw_inv = true
			if t > P.IFRAME_END + 0.001 and inv:
				bad += 1
		elif i > 3:
			saw_vuln_after = saw_vuln_after or not P.is_invulnerable()
	CT.touch_move = Vector2.ZERO
	check(bad == 0 and saw_inv, "i-frames only inside %.2f-%.2fs of the roll" % [P.IFRAME_START, P.IFRAME_END])
	check(saw_vuln_after and not P.is_invulnerable(), "no invulnerability after the roll ends")
	await frames(30)
	var hp_before: float = GS.hp
	P.take_damage(10.0, Vector3.ZERO)
	check(GS.hp < hp_before, "damage applies outside the dodge window")

	print("== scarab: FSM, melee damage, death, loot, xp")
	P.respawn(Vector3(-40, Terrain.height_at(-40, 45) + 0.3, 45))
	GS.hp = GS.max_hp()
	var xp0: int = GS.xp
	var kills0: int = GS.kills
	var sc: Node3D = EnemyScript.spawn(game, "scarab", Vector3(-40, Terrain.height_at(-40, 38) + 0.4, 38))
	await frames(5)
	var seen := {}
	var hurt := false
	var hp_start: float = GS.hp
	for i in 420:
		await physics_frame
		if is_instance_valid(sc):
			seen[sc.state_name()] = true
		if GS.hp < hp_start:
			hurt = true
			break
	check(seen.has("chase") and seen.has("windup") and hurt, "scarab FSM: chase -> windup -> attack damages the player (%s)" % ", ".join(seen.keys()))
	P.respawn(P.global_position)
	GS.hp = GS.max_hp()
	var guard := 0
	while is_instance_valid(sc) and not sc.is_dead() and guard < 900:
		guard += 1
		var to: Vector3 = sc.global_position - P.global_position
		to.y = 0.0
		if to.length() > 0.1:
			P.rotation.y = atan2(-to.x, -to.z)
		if to.length() < 2.6:
			P._try_attack()
		else:
			CT.touch_move = Vector2(0, -1)
			var yaw: float = P.rotation.y
			game.cam_rig.yaw = yaw
		await physics_frame
		GS.hp = maxf(GS.hp, 50.0)
	CT.touch_move = Vector2.ZERO
	check(not is_instance_valid(sc) or sc.is_dead(), "player sword kills the scarab")
	check(GS.xp > xp0 or GS.level > 1, "killing grants XP")
	check(GS.kills == kills0 + 1, "kill counter increments")
	var pickups := 0
	for c in game.get_children():
		if c.get_script() != null and String(c.get_script().resource_path).ends_with("pickup.gd"):
			pickups += 1
	check(pickups >= 1, "enemy dropped loot pickups (%d)" % pickups)
	await secs(0.2)

	print("== no attacks through walls / at long range")
	var wall := StaticBody3D.new()
	wall.collision_layer = 1
	var wcs := CollisionShape3D.new()
	var wbs := BoxShape3D.new()
	wbs.size = Vector3(60, 12, 1.0)
	wcs.shape = wbs
	wall.add_child(wcs)
	game.add_child(wall)
	var wx := -40.0
	var wz := 20.0
	wall.position = Vector3(wx, Terrain.height_at(wx, wz) + 5.0, wz)
	P.respawn(Vector3(wx, Terrain.height_at(wx, wz + 6) + 0.3, wz + 6))
	GS.hp = GS.max_hp()
	var sc2: Node3D = EnemyScript.spawn(game, "scarab", Vector3(wx, Terrain.height_at(wx, wz - 3) + 0.4, wz - 3))
	var wr: Node3D = EnemyScript.spawn(game, "wraith", Vector3(wx + 2, Terrain.height_at(wx + 2, wz - 5) + 0.4, wz - 5))
	await frames(100)
	check(GS.hp >= GS.max_hp() - 0.01, "enemies behind a wall cannot hurt the player (hp %.0f)" % GS.hp)
	sc2.queue_free()
	wr.queue_free()
	wall.queue_free()
	await frames(5)

	print("== wraith: ranged attack at range with line of sight")
	P.respawn(Vector3(-40, Terrain.height_at(-40, 45) + 0.3, 45))
	GS.hp = GS.max_hp()
	var wr2: Node3D = EnemyScript.spawn(game, "wraith", Vector3(-40, Terrain.height_at(-40, 35) + 0.4, 35))
	var hp_w: float = GS.hp
	var fired := false
	for i in 600:
		await physics_frame
		if GS.hp < hp_w:
			fired = true
			break
	check(fired, "wraith orb reaches and damages a stationary player")
	wr2.queue_free()
	await frames(3)

	print("== rune puzzle")
	var pz = game.ui.panels.puzzle
	GS.puzzle_dials = [0, 0, 0]
	pz.refresh()
	pz._attune_pressed()
	check(not GS.puzzle_solved, "wrong rune combination is rejected")
	GS.puzzle_dials = [1, 2, 0]
	pz.refresh()
	pz._attune_pressed()
	check(GS.puzzle_solved, "correct combination (Moon, Eye, Sun) solves the puzzle")
	await secs(0.3)
	game.ui.close_all()
	await secs(4.4)
	check(game.refs.puzzle.open and game.refs.puzzle.door.collision_layer == 0, "temple door opens after the puzzle")

	print("== relic fragments")
	for id in ["frag_alcove", "frag_wraith", "frag_temple"]:
		var f: Dictionary = game.refs.fragments[id]
		check(f.node.enabled, "fragment %s is collectable" % id)
		game._on_interact(f.node)
	check(GS.fragments_found == 3 and GS.count("relic_fragment") == 3 and GS.quest_stage == 2, "three fragments move the quest to stage 2")

	print("== gate")
	P.respawn(Vector3(0, Terrain.height_at(0, -48) + 0.3, -48))
	game.cam_rig.yaw = 0.0
	await frames(20)
	CT.touch_move = Vector2(0, -1)
	await frames(240)
	CT.touch_move = Vector2.ZERO
	check(P.global_position.z > -56.5, "closed gate blocks the way north (z=%.1f)" % P.global_position.z)
	game._on_interact(game.refs.gate.node)
	check(GS.gate_open and GS.quest_stage == 3 and GS.count("relic_fragment") == 0, "gate opens, consuming the three fragments")
	await secs(9.0)
	check(game.refs.gate.door.collision_layer == 0, "gate door finishes sinking and stops colliding")
	check(game.boss != null and game.boss.state_name() == "dormant", "boss is still dormant while the player is south of the gate")
	P.respawn(Vector3(0, Terrain.height_at(0, -50) + 0.3, -50))
	game.cam_rig.yaw = 0.0
	await frames(20)
	CT.touch_move = Vector2(0, -1)
	await frames(200)
	CT.touch_move = Vector2.ZERO
	check(P.global_position.z < -60.0, "player can walk through the open gate (z=%.1f)" % P.global_position.z)

	print("== ridge cannot be bypassed")
	var escaped := false
	GS.hp = 99999.0  # the Warden has woken by now and would otherwise kill the player while we probe the ridge
	for x in [-30.0, -18.0, -12.0, -9.0, 9.0, 12.0, 18.0, 30.0]:
		P.respawn(Vector3(x, Terrain.height_at(x, -45) + 0.3, -45))
		GS.hp = 99999.0
		game.cam_rig.yaw = 0.0
		await frames(10)
		CT.touch_move = Vector2(0, -1)
		await frames(240)
		if P.global_position.z < -57.0:
			escaped = true
			print("    escaped at x=", x, " z=", P.global_position.z)
	CT.touch_move = Vector2.ZERO
	check(not escaped, "no way around the gate along the ridge")

	print("== Hollow Warden")
	var B: Node3D = game.boss
	# the earlier walk through the gate legitimately woke it: lure it home and let it reset first
	print("    [diag] before leash: boss=", B.state_name(), " at ", B.global_position, " hp=", B.hp, " paused=", paused, " modal=", game.ui.is_modal_open(), " open=", game.ui.panels.keys().filter(func(k: String) -> bool: return game.ui.panels[k].is_open), " hp=", GS.hp, " player=", P.state, " pos=", P.global_position, " valid=", is_instance_valid(B), " processing=", B.is_physics_processing())
	P.respawn(Vector3(0, Terrain.height_at(0, -30) + 0.3, -30))
	GS.hp = 99999.0
	for i in 1500:
		await physics_frame
		GS.hp = 99999.0
		if B.state_name() == "dormant":
			break
	print("    [diag] after leash: boss=", B.state_name(), " at ", B.global_position, " hp=", B.hp, " paused=", paused, " dist_home=", B.global_position.distance_to(B.home), " player_dist=", B._dist)
	check(B.state_name() == "dormant", "boss gives up and returns to sleep when the player leaves (leash)")
	check(B.hp >= B.max_hp - 0.1, "boss heals back to full after resetting")
	P.respawn(Vector3(0, Terrain.height_at(0, -64) + 0.3, -64))
	GS.hp = 99999.0
	game.cam_rig.yaw = 0.0
	var hits: Array = [0]
	P.damaged.connect(func(_a: float) -> void: hits[0] += 1)
	var attacks := {}
	var tele_seen := false
	var woke := false
	for i in 3600:
		await physics_frame
		if not is_instance_valid(B):
			break
		if B.state_name() == "windup" and B._atk != "":
			attacks[B._atk] = true
		if B._tele != null:
			tele_seen = true
		woke = woke or B.state_name() != "dormant"
		GS.hp = 99999.0
		if attacks.size() >= 4 and hits[0] >= 2:
			break
	check(woke, "boss wakes when the player enters the arena")
	check(game.boss_info().active and game.boss_info().frac > 0.9, "boss health bar info is active")
	check(attacks.size() >= 3, "boss uses several attacks: %s" % ", ".join(attacks.keys()))
	check(tele_seen, "boss telegraphs its ground attacks")
	check(hits[0] >= 1, "boss attacks hurt a standing player (%d hits)" % hits[0])
	B.take_damage(B.max_hp * 0.55, P.global_position, P)
	await frames(10)
	check(B._phase == 2, "boss enters phase 2 below half health")
	await frames(240)
	B.take_damage(99999.0, P.global_position, P)
	await frames(5)
	check(GS.boss_defeated and GS.quest_stage == 4, "boss death completes quest stage 4")
	check(game.refs.relic.node.enabled, "relic becomes available")

	print("== relic and quest completion")
	GS.hp = GS.max_hp()
	var c2: int = GS.coins
	game._on_interact(game.refs.relic.node)
	check(GS.quest_completed and GS.quest_stage == 5 and GS.coins >= c2 + 250 and GS.count("caravan_blade") == 1, "claiming the relic rewards coins and the Caravan Blade")
	check(game.ui.is_open("end"), "quest-complete screen is shown")
	game.ui.close_all()

	print("== save / load")
	await frames(3)
	check(GS.save_game() and GS.has_save(), "save succeeds")
	var snap := {"level": GS.level, "xp": GS.xp, "coins": GS.coins, "stage": GS.quest_stage, "opened": GS.opened_ids.duplicate(), "solved": GS.puzzle_solved, "gate": GS.gate_open}
	GS.coins = 7
	GS.level = 1
	GS.quest_stage = 0
	GS.opened_ids = []
	check(GS.load_game(), "load succeeds")
	check(GS.coins == snap.coins and GS.level == snap.level and GS.quest_stage == snap.stage and GS.opened_ids == snap.opened and GS.puzzle_solved and GS.gate_open, "loaded state equals saved state")
	GS.save_game()  # second save creates the .bak
	var f := FileAccess.open(GS.save_path, FileAccess.WRITE)
	f.store_string("{\"v\":1,\"sha\":\"nope\",\"payload\":\"{}\"}")
	f.close()
	GS.coins = 1
	check(GS.load_game() and GS.coins == snap.coins, "tampered save falls back to the verified backup")
	var f2 := FileAccess.open(GS.save_path, FileAccess.WRITE)
	f2.store_string("garbage {{{ not json")
	f2.close()
	var f3 := FileAccess.open(GS.save_path + ".bak", FileAccess.WRITE)
	f3.store_string("")
	f3.close()
	check(not GS.load_game(), "fully corrupted save is rejected without crashing")
	GS.delete_save()
	check(not GS.has_save(), "reset removes the save files")
	GS.save_game()

	print("== pause / resume")
	var sc3: Node3D = EnemyScript.spawn(game, "scarab", Vector3(-20, Terrain.height_at(-20, 45) + 0.4, 45))
	P.respawn(Vector3(-20, Terrain.height_at(-20, 48) + 0.3, 48))
	await frames(5)
	game.ui.open_panel("pause")
	check(paused and not CT.enabled, "pause menu pauses the tree and disables controls")
	var p0: Vector3 = sc3.global_position
	await frames(40)
	check(sc3.global_position.distance_to(p0) < 0.001, "world is frozen while paused")
	game.ui.close_all()
	check(not paused and CT.enabled, "closing the menu resumes the game")
	sc3.queue_free()
	for id in ["inventory", "journal", "map", "skills", "settings", "camp", "puzzle", "pause"]:
		game.ui.open_panel(id)
		await frames(2)
		check(game.ui.is_open(id), "panel '%s' opens" % id)
		game.ui.close_all()
		await frames(2)

	print("== camp rest")
	GS.hp = 10.0
	game.rest_at_camp()
	check(GS.hp >= GS.max_hp() - 0.01, "resting restores health")
	GS.delete_save()
	GS.save_game()

	print("== fast travel")
	GS.discover("ruins")
	GS.checkpoint_id = "ruins"
	P.respawn(Vector3(-62, Terrain.height_at(-62, 61) + 0.3, 61))
	await frames(5)
	check(game.can_fast_travel(), "fast travel allowed when safe")
	game.travel_to("ruins")
	await secs(1.6)
	var rs: Vector2 = Items.LOCATIONS.ruins.spawn
	check(Vector2(P.global_position.x, P.global_position.z).distance_to(rs) < 3.0, "travel teleports the player to the waystone spawn")

	print("== death and respawn")
	GS.hp = GS.max_hp()
	P.take_damage(99999.0, Vector3.ZERO)
	check(P.is_dead(), "lethal damage kills the player")
	await secs(2.2)
	check(game.ui.is_open("end"), "defeat screen appears")
	game._on_end_choice("retry")
	await secs(1.6)
	check(not P.is_dead() and GS.hp >= GS.max_hp() - 0.01, "retry respawns the player at full health")
	game.ui.close_all()

	GS.delete_save()
	print("\nSMOKE TEST: %d passed, %d failed" % [passes, fails])
	quit(1 if fails > 0 else 0)
