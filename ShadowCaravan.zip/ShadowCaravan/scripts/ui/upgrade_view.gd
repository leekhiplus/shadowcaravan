extends VBoxContainer
## Shared upgrade UI (used by the Skills screen and the Camp screen's Upgrade tab):
## character stats on the left, health / weapon / stamina upgrades and the camp upgrade on the right.
## Purchases only work at the camp; elsewhere the buttons explain how to unlock them.

const Pal := preload("res://scripts/data/pal.gd")
const UI := preload("res://scripts/ui/ui_kit.gd")
const Items := preload("res://scripts/data/items.gd")

var at_camp := false
var _stats: VBoxContainer
var _cards: VBoxContainer
var _xp_bar: ProgressBar


func _init() -> void:
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_theme_constant_override("separation", 10)


func _ready() -> void:
	var row := HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation", 28)
	add_child(row)
	var left := VBoxContainer.new()
	left.custom_minimum_size = Vector2(300, 0)
	left.add_theme_constant_override("separation", 6)
	row.add_child(left)
	_stats = VBoxContainer.new()
	_stats.add_theme_constant_override("separation", 4)
	left.add_child(_stats)
	_xp_bar = ProgressBar.new()
	_xp_bar.custom_minimum_size = Vector2(0, 22)
	_xp_bar.show_percentage = false
	_xp_bar.add_theme_stylebox_override("fill", UI.box(Pal.GOLD_DARK, Color(0, 0, 0, 0), 0, 4))
	left.add_child(_xp_bar)
	var sc := UI.scroll()
	row.add_child(sc)
	_cards = VBoxContainer.new()
	_cards.add_theme_constant_override("separation", 10)
	_cards.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(_cards)
	refresh()


func refresh() -> void:
	if _stats == null:
		return
	for c in _stats.get_children():
		c.queue_free()
	_stats.add_child(UI.title("Level %d" % GameState.level, 36, Pal.GOLD_LIGHT))
	_stats.add_child(_stat("Health", "%d / %d" % [int(ceil(GameState.hp)), int(GameState.max_hp())]))
	_stats.add_child(_stat("Stamina", str(int(GameState.max_stamina()))))
	_stats.add_child(_stat("Attack", "%d" % int(GameState.weapon_damage())))
	_stats.add_child(_stat("Defense", "%d" % int(GameState.armor_defense())))
	_stats.add_child(_stat("Coins", str(GameState.coins)))
	_stats.add_child(_stat("Experience", "%d / %d" % [GameState.xp, Items.xp_for_next(GameState.level)]))
	_xp_bar.max_value = Items.xp_for_next(GameState.level)
	_xp_bar.value = GameState.xp
	for c in _cards.get_children():
		c.queue_free()
	if not at_camp:
		var note := UI.label("Visit the anvil at your Caravan Camp to spend resources. (Pause menu > Return to Camp)", 21, Pal.SAND, HORIZONTAL_ALIGNMENT_LEFT, true)
		_cards.add_child(note)
	for id in Items.UPGRADES:
		_cards.add_child(_upgrade_card(String(id)))
	_cards.add_child(_camp_card())


func _stat(k: String, v: String) -> Control:
	var h := HBoxContainer.new()
	h.add_child(UI.label(k, 23, Pal.TEXT_DIM))
	h.add_child(UI.hfill())
	h.add_child(UI.label(v, 23, Pal.TEXT))
	return h


func _cost_text(cost: Dictionary) -> String:
	var parts: Array[String] = []
	if int(cost.get("coins", 0)) > 0:
		parts.append("%d coins" % int(cost.coins))
	var items: Dictionary = cost.get("items", {})
	for k in items:
		parts.append("%d x %s" % [int(items[k]), String(Items.item(String(k)).name)])
	return ", ".join(parts) if parts.size() > 0 else "Free"


func _card_frame() -> PanelContainer:
	var p := PanelContainer.new()
	var sb := UI.box(Color(0.05, 0.07, 0.13, 0.9), Pal.GOLD_DARK, 2, 10)
	sb.content_margin_left = 14
	sb.content_margin_right = 14
	sb.content_margin_top = 10
	sb.content_margin_bottom = 12
	p.add_theme_stylebox_override("panel", sb)
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return p


func _upgrade_card(id: String) -> Control:
	var info: Dictionary = Items.UPGRADES[id]
	var rank: int = int(GameState.upgrades.get(id, 0))
	var maxr: int = int(info.max)
	var p := _card_frame()
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	p.add_child(h)
	h.add_child(UI.icon(String(info.icon), 64, Pal.GOLD_LIGHT, true))
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 2)
	h.add_child(v)
	var top := HBoxContainer.new()
	top.add_child(UI.label(String(info.name), 26, Pal.GOLD_LIGHT))
	top.add_child(UI.hfill())
	top.add_child(UI.label("Rank %d / %d" % [rank, maxr], 22, Pal.TURQUOISE))
	v.add_child(top)
	v.add_child(UI.label(String(info.desc), 20, Pal.TEXT_DIM))
	var b: Button
	if rank >= maxr:
		b = UI.button("Maxed", "check", "normal", Vector2(0, 54))
		b.disabled = true
	else:
		var cost := Items.upgrade_cost(id, rank)
		b = UI.button("Upgrade: " + _cost_text(cost), "arrow_up", "primary", Vector2(0, 54))
		b.add_theme_font_size_override("font_size", 21)
		b.disabled = not at_camp or not GameState.can_afford(cost)
		if not at_camp:
			b.text = "Upgrade at camp"
		b.pressed.connect(func():
			if GameState.buy_upgrade(id):
				AudioMgr.play("upgrade")
				refresh())
	v.add_child(b)
	return p


func _camp_card() -> Control:
	var lvl := GameState.camp_level
	var p := _card_frame()
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	p.add_child(h)
	h.add_child(UI.icon("camp", 64, Pal.GOLD_LIGHT, true))
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 2)
	h.add_child(v)
	var top := HBoxContainer.new()
	top.add_child(UI.label("Caravan Camp", 26, Pal.GOLD_LIGHT))
	top.add_child(UI.hfill())
	top.add_child(UI.label("Level %d / %d" % [lvl, Items.CAMP_MAX_LEVEL], 22, Pal.TURQUOISE))
	v.add_child(top)
	v.add_child(UI.label(String(Items.CAMP_DESC[lvl - 1]), 20, Pal.TEXT_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))
	var b: Button
	if lvl >= Items.CAMP_MAX_LEVEL:
		b = UI.button("Camp fully upgraded", "check", "normal", Vector2(0, 54))
		b.disabled = true
	else:
		var cost := Items.camp_upgrade_cost(lvl)
		b = UI.button("Improve camp: " + _cost_text(cost), "camp", "primary", Vector2(0, 54))
		b.add_theme_font_size_override("font_size", 21)
		b.disabled = not at_camp or not GameState.can_afford(cost)
		if not at_camp:
			b.text = "Upgrade at camp"
		b.pressed.connect(func():
			if GameState.upgrade_camp():
				AudioMgr.play("upgrade")
				refresh())
	v.add_child(b)
	return p
