extends Control
## A Control that renders one procedural icon (or rune) - used in menus, inventory slots and buttons.

const Pal := preload("res://scripts/data/pal.gd")
const Icons := preload("res://scripts/ui/icons.gd")

var icon_id := ""
var rune_index := -1
var tint := Pal.GOLD_LIGHT
var framed := false
var frame_color := Pal.GOLD_DARK


func _init(id: String = "", size: float = 48.0) -> void:
	icon_id = id
	custom_minimum_size = Vector2(size, size)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func set_icon(id: String, col: Color = Pal.GOLD_LIGHT) -> void:
	icon_id = id
	rune_index = -1
	tint = col
	queue_redraw()


func set_rune(idx: int, col: Color = Pal.TURQUOISE) -> void:
	rune_index = idx
	tint = col
	queue_redraw()


func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	if framed:
		var sb := StyleBoxFlat.new()
		sb.bg_color = Pal.OBSIDIAN_SOFT
		sb.border_color = frame_color
		sb.set_border_width_all(2)
		sb.set_corner_radius_all(6)
		draw_style_box(sb, r)
	var c := r.get_center()
	var s := minf(size.x, size.y) * (0.36 if framed else 0.46)
	if rune_index >= 0:
		Icons.draw_rune(self, rune_index, c, s, tint)
	elif icon_id != "":
		Icons.draw_icon(self, icon_id, c, s, tint)
