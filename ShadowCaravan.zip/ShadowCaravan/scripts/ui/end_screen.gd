extends "res://scripts/ui/panel_base.gd"
## Quest-complete, victory and defeat screens (one panel, three presentations).

const Items := preload("res://scripts/data/items.gd")

signal choice(id: String)

var _kind := ""


func _init() -> void:
	super("", Vector2(960, 560), false)
	dim_alpha = 0.78


func _build() -> void:
	title_label.visible = false


func _clear_body() -> void:
	for c in body.get_children():
		c.queue_free()


func _btn(text: String, icon: String, kind: String, id: String) -> Button:
	var b := UI.button(text, icon, kind, Vector2(340, 70))
	b.pressed.connect(func():
		close()
		choice.emit(id))
	return b


func _row(buttons: Array) -> Control:
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 24)
	for b in buttons:
		h.add_child(b)
	return h


func show_kind(kind: String) -> void:
	_kind = kind
	_clear_body()
	match kind:
		"quest":
			body.add_child(UI.label("QUEST COMPLETE", 24, Pal.TURQUOISE, HORIZONTAL_ALIGNMENT_CENTER))
			body.add_child(UI.title("The Lost Caravan", 66, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER))
			body.add_child(UI.divider(20))
			body.add_child(UI.label("The Ancient Relic hums in your hands, and the wind over the dunes finally carries the sound of bells - the caravan's lanterns, far to the north.", 25, Pal.TEXT, HORIZONTAL_ALIGNMENT_CENTER, true))
			var rw := HBoxContainer.new()
			rw.alignment = BoxContainer.ALIGNMENT_CENTER
			rw.add_theme_constant_override("separation", 36)
			for r in [["coin", "+250 coins"], ["scimitar", "Caravan Blade"], ["star", "+%d XP" % int(Items.XP_VALUES.quest)]]:
				var col := VBoxContainer.new()
				col.add_theme_constant_override("separation", 4)
				var ic := UI.icon(String(r[0]), 78, Pal.GOLD_LIGHT, true)
				ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
				col.add_child(ic)
				col.add_child(UI.label(String(r[1]), 23, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER))
				rw.add_child(col)
			body.add_child(rw)
			body.add_child(UI.hfill())
			body.add_child(_row([_btn("Continue", "arrow_up", "primary", "victory")]))
		"victory":
			body.add_child(UI.label("THE JOURNEY CONTINUES", 24, Pal.TURQUOISE, HORIZONTAL_ALIGNMENT_CENTER))
			body.add_child(UI.title("Victory", 74, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER))
			body.add_child(UI.divider(20))
			var mins := int(GameState.play_time / 60.0)
			var disc := 0
			for id in Items.LOCATIONS:
				if GameState.is_discovered(String(id)):
					disc += 1
			var g := GridContainer.new()
			g.columns = 4
			g.add_theme_constant_override("h_separation", 34)
			g.add_theme_constant_override("v_separation", 8)
			g.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
			for kv in [["Time played", "%d min" % mins], ["Level reached", str(GameState.level)], ["Enemies defeated", str(GameState.kills)], ["Locations found", "%d / %d" % [disc, Items.LOCATIONS.size()]], ["Chests opened", "%d / %d" % [GameState.chests_opened(), Items.CHESTS.size()]], ["Camp level", "%d / %d" % [GameState.camp_level, Items.CAMP_MAX_LEVEL]]]:
				g.add_child(UI.label(kv[0], 24, Pal.TEXT_DIM))
				var vl := UI.label(kv[1], 24, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_RIGHT)
				vl.custom_minimum_size.x = 90
				g.add_child(vl)
			body.add_child(g)
			body.add_child(UI.hfill())
			body.add_child(_row([_btn("Keep Exploring", "arrow_up", "primary", "explore"), _btn("Main Menu", "home", "normal", "menu")]))
		"defeat":
			body.add_child(UI.label("THE DUNES CLAIM ANOTHER", 24, Pal.BLOOD, HORIZONTAL_ALIGNMENT_CENTER))
			body.add_child(UI.title("You Have Fallen", 74, Color("e5605c"), HORIZONTAL_ALIGNMENT_CENTER))
			body.add_child(UI.divider(20, Pal.BLOOD))
			body.add_child(UI.label("Your lantern gutters, but it does not go out. You wake at your last waystone with your belongings intact.", 26, Pal.TEXT, HORIZONTAL_ALIGNMENT_CENTER, true))
			body.add_child(UI.hfill())
			body.add_child(_row([_btn("Retry from Checkpoint", "flame", "primary", "retry"), _btn("Main Menu", "home", "normal", "menu")]))
	open()
	if kind == "quest":
		AudioMgr.play("quest_done")


func on_back() -> bool:
	return true  # these screens can only be left through their buttons
