extends "res://scripts/ui/panel_base.gd"
## Dialogue / lore reader. Pages advance with Next; the last page shows the action button.

var _speaker: Label
var _text: Label
var _next: Button
var _skip: Button
var _pages: Array = []
var _page := 0
var _done: Callable
var _final_label := "Continue"


func _init() -> void:
	super("", Vector2(1000, 400), false)
	dim_alpha = 0.5


func _build() -> void:
	title_label.visible = false
	_speaker = UI.title("", 40, Pal.GOLD_LIGHT)
	body.add_child(_speaker)
	_text = UI.label("", 28, Pal.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true)
	_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_child(_text)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	_skip = UI.button("Close", "", "ghost", Vector2(200, 64))
	_skip.pressed.connect(_finish_without)
	row.add_child(_skip)
	row.add_child(UI.hfill())
	_next = UI.button("Next", "arrow_up", "primary", Vector2(320, 68))
	_next.pressed.connect(_advance)
	row.add_child(_next)
	body.add_child(row)


## pages: Array[String]. on_done runs when the last page's button is pressed.
func show_dialogue(speaker: String, pages: Array, final_label: String, on_done: Callable, closable_early: bool = true) -> void:
	_pages = pages
	_page = 0
	_done = on_done
	_final_label = final_label
	_speaker.text = speaker
	_skip.visible = closable_early
	_render()
	open()


func _render() -> void:
	_text.text = String(_pages[_page])
	_next.text = _final_label if _page >= _pages.size() - 1 else "Next"


func _advance() -> void:
	if _page < _pages.size() - 1:
		_page += 1
		_render()
		AudioMgr.play("ui_click")
	else:
		close()
		if _done.is_valid():
			_done.call()


func _finish_without() -> void:
	close()


func on_back() -> bool:
	if _skip.visible:
		close()
		return true
	return true
