extends "res://scripts/ui/panel_base.gd"
## Small yes/no modal. Usage: dlg.ask("Text", "Yes label", callable, danger)

var _msg: Label
var _yes: Button
var _no: Button
var _on_yes: Callable


func _init() -> void:
	super("", Vector2(760, 330), true)
	dim_alpha = 0.72


func _build() -> void:
	frame.visible = true
	title_label.add_theme_font_size_override("font_size", 38)
	_msg = UI.label("", 28, Pal.TEXT, HORIZONTAL_ALIGNMENT_CENTER, true)
	_msg.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_msg.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	body.add_child(_msg)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 26)
	_no = UI.button("Cancel", "", "normal", Vector2(250, 70))
	_no.pressed.connect(close)
	_yes = UI.button("Confirm", "check", "danger", Vector2(290, 70))
	_yes.pressed.connect(_confirmed)
	row.add_child(_no)
	row.add_child(_yes)
	body.add_child(row)


func ask(title: String, text: String, yes_label: String, on_yes: Callable, danger: bool = true) -> void:
	title_label.text = title
	_msg.text = text
	_yes.text = yes_label
	_on_yes = on_yes
	var kind := "danger" if danger else "primary"
	var tmp := UI.button(yes_label, "check", kind, Vector2(290, 70))
	for k in ["normal", "hover", "pressed", "disabled"]:
		_yes.add_theme_stylebox_override(k, tmp.get_theme_stylebox(k))
	tmp.queue_free()
	open()


func _confirmed() -> void:
	close()
	if _on_yes.is_valid():
		_on_yes.call()
