extends Control
## A framed dark-fantasy panel: obsidian fill, antique-gold border, ornament overlay.
## Add child controls to `content` (a VBoxContainer inside a MarginContainer).

const Pal := preload("res://scripts/data/pal.gd")
const Ornament := preload("res://scripts/ui/ornament.gd")

var content: VBoxContainer
var bg: Panel


func _init(bg_alpha: float = 0.96, margin: int = 30, tint: Color = Pal.GOLD_DARK) -> void:
	bg = Panel.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(Pal.OBSIDIAN_SOFT.r, Pal.OBSIDIAN_SOFT.g, Pal.OBSIDIAN_SOFT.b, bg_alpha)
	sb.border_color = tint
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(14)
	sb.shadow_size = 26
	sb.shadow_color = Color(0, 0, 0, 0.6)
	sb.shadow_offset = Vector2(0, 6)
	bg.add_theme_stylebox_override("panel", sb)
	add_child(bg)
	# soft midnight wash fading in over the lower half gives the panel some layered depth
	var grad := Gradient.new()
	grad.offsets = PackedFloat32Array([0.0, 0.4, 1.0])
	grad.colors = PackedColorArray([Color(Pal.MIDNIGHT, 0.0), Color(Pal.MIDNIGHT, 0.0), Color(Pal.MIDNIGHT, 0.6)])
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	gt.width = 8
	gt.height = 128
	var wash := TextureRect.new()
	wash.texture = gt
	wash.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	wash.stretch_mode = TextureRect.STRETCH_SCALE
	wash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	wash.offset_left = 6
	wash.offset_right = -6
	wash.offset_top = 6
	wash.offset_bottom = -6
	wash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(wash)
	add_child(Ornament.new("panel"))
	var m := MarginContainer.new()
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	m.add_theme_constant_override("margin_left", margin)
	m.add_theme_constant_override("margin_right", margin)
	m.add_theme_constant_override("margin_top", margin - 6)
	m.add_theme_constant_override("margin_bottom", margin - 6)
	add_child(m)
	content = VBoxContainer.new()
	content.add_theme_constant_override("separation", 12)
	m.add_child(content)
