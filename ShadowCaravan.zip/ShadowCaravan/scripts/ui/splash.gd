extends Control
## Studio splash: Zafronix sigil -> Shadow Caravan title card -> main menu. Tap to skip.

const Pal := preload("res://scripts/data/pal.gd")
const UI := preload("res://scripts/ui/ui_kit.gd")
const Backdrop := preload("res://scripts/ui/backdrop.gd")

var _studio: Control
var _title: Control
var _skipped := false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Pal.OBSIDIAN
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	# --- studio card
	_studio = CenterContainer.new()
	_studio.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var sv := VBoxContainer.new()
	sv.alignment = BoxContainer.ALIGNMENT_CENTER
	sv.add_theme_constant_override("separation", 14)
	_studio.add_child(sv)
	var sigil := _Sigil.new()
	sigil.custom_minimum_size = Vector2(150, 150)
	sv.add_child(sigil)
	sv.add_child(UI.title("ZAFRONIX", 62, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER))
	var sub := UI.label("S T U D I O S", 22, Pal.SAND_DARK, HORIZONTAL_ALIGNMENT_CENTER)
	sv.add_child(sub)
	add_child(_studio)
	_studio.modulate.a = 0.0

	# --- title card
	var back := Backdrop.new()
	back.show_caravan = true
	back.modulate.a = 0.0
	add_child(back)
	_title = CenterContainer.new()
	_title.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var tv := VBoxContainer.new()
	tv.alignment = BoxContainer.ALIGNMENT_CENTER
	tv.add_theme_constant_override("separation", 8)
	_title.add_child(tv)
	tv.add_child(UI.label("ZAFRONIX STUDIOS PRESENTS", 22, Pal.SAND, HORIZONTAL_ALIGNMENT_CENTER))
	tv.add_child(UI.title("SHADOW CARAVAN", 96, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER))
	tv.add_child(UI.divider(22))
	tv.add_child(UI.label("A desert tale of lost cities and forgotten gates", 26, Pal.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER))
	add_child(_title)
	_title.modulate.a = 0.0

	_run(back)


func _run(back: Control) -> void:
	var tw := create_tween()
	tw.tween_property(_studio, "modulate:a", 1.0, 0.8)
	tw.tween_interval(1.0)
	tw.tween_property(_studio, "modulate:a", 0.0, 0.5)
	tw.tween_callback(func(): AudioMgr.play("ui_open", -6.0))
	tw.tween_property(back, "modulate:a", 1.0, 0.9)
	tw.parallel().tween_property(_title, "modulate:a", 1.0, 0.9)
	tw.tween_interval(1.6)
	tw.tween_callback(_go)


func _go() -> void:
	if _skipped:
		return
	_skipped = true
	Router.go("res://scenes/main_menu.tscn")


func _gui_input(event: InputEvent) -> void:
	if (event is InputEventMouseButton and event.pressed) or (event is InputEventScreenTouch and event.pressed):
		_go()


class _Sigil extends Control:
	func _draw() -> void:
		var c := size * 0.5
		var r := minf(size.x, size.y) * 0.46
		var gold := Color("c9a24b")
		var light := Color("ecd592")
		draw_arc(c, r, 0, TAU, 64, gold, 3.0, true)
		draw_arc(c, r * 0.82, 0, TAU, 64, Color(gold, 0.45), 1.5, true)
		# crescent: pale disc with a dark bite taken out of it
		draw_circle(c, r * 0.55, light)
		draw_circle(c + Vector2(r * 0.24, -r * 0.06), r * 0.48, Color("0a0b10"))
		# four-pointed star
		var s := r * 0.3
		var sc := c + Vector2(r * 0.18, -r * 0.05)
		draw_colored_polygon(PackedVector2Array([sc + Vector2(0, -s), sc + Vector2(s * 0.22, -s * 0.22), sc + Vector2(s, 0), sc + Vector2(s * 0.22, s * 0.22), sc + Vector2(0, s), sc + Vector2(-s * 0.22, s * 0.22), sc + Vector2(-s, 0), sc + Vector2(-s * 0.22, -s * 0.22)]), Color("3fd0c9"))
