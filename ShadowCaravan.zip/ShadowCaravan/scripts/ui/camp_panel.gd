extends "res://scripts/ui/panel_base.gd"
## Caravan camp screen: Rest, Craft, Upgrade, Storage tabs. Opened from the tent, campfire,
## anvil and storage chest in the camp (the tab depends on which one you used).

const Items := preload("res://scripts/data/items.gd")
const UpgradeView := preload("res://scripts/ui/upgrade_view.gd")
const IconView := preload("res://scripts/ui/icon_view.gd")

var game: Node
var _tab := "rest"
var _tab_btns: Dictionary = {}
var _content: Control
var _msg: Label


func _init() -> void:
	super("Caravan Camp", Vector2(1120, 650))


func _build() -> void:
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 10)
	var defs := [["rest", "Rest", "tent"], ["craft", "Craft", "hammer"], ["upgrade", "Upgrade", "anvil"], ["storage", "Storage", "chest"]]
	for d in defs:
		var b := UI.button(String(d[1]), String(d[2]), "tab", Vector2(230, 58))
		b.add_theme_font_size_override("font_size", 23)
		b.pressed.connect(_select.bind(String(d[0])))
		tabs.add_child(b)
		_tab_btns[d[0]] = b
	body.add_child(tabs)
	_content = VBoxContainer.new()
	_content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_child(_content)
	_msg = UI.label("", 22, Pal.TURQUOISE, HORIZONTAL_ALIGNMENT_CENTER)
	body.add_child(_msg)
	GameState.inventory_changed.connect(_on_changed)


func _exit_tree() -> void:
	if GameState.inventory_changed.is_connected(_on_changed):
		GameState.inventory_changed.disconnect(_on_changed)


func _on_changed() -> void:
	if is_open and _tab in ["craft", "storage"]:
		_render()


func open_tab(tab: String) -> void:
	_tab = tab
	open()


func refresh() -> void:
	_msg.text = ""
	_render()


func _select(t: String) -> void:
	_tab = t
	_msg.text = ""
	_render()


func _clear() -> VBoxContainer:
	for c in _content.get_children():
		c.queue_free()
	var v := VBoxContainer.new()
	v.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 10)
	_content.add_child(v)
	return v


func _render() -> void:
	if _content == null:
		return
	for k in _tab_btns:
		_tab_btns[k].set_pressed_no_signal(k == _tab)
	var v := _clear()
	match _tab:
		"rest":
			_render_rest(v)
		"craft":
			_render_craft(v)
		"upgrade":
			var uv := UpgradeView.new()
			uv.at_camp = true
			v.add_child(uv)
		"storage":
			_render_storage(v)


func _render_rest(v: VBoxContainer) -> void:
	v.add_child(UI.spacer(10))
	var row := HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation", 30)
	v.add_child(row)
	row.add_child(UI.icon("flame", 150, Pal.GOLD_LIGHT))
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 12)
	row.add_child(col)
	col.add_child(UI.title("Rest by the fire", 38, Pal.GOLD_LIGHT))
	col.add_child(UI.label("Sleep in the tent until the moon turns. Health and stamina are fully restored and the game is saved.", 24, Pal.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true))
	var hp_txt := "Health %d / %d     Stamina %d / %d" % [int(ceil(GameState.hp)), int(GameState.max_hp()), int(GameState.stamina), int(GameState.max_stamina())]
	col.add_child(UI.label(hp_txt, 24, Pal.SAND))
	if GameState.camp_level >= 3:
		col.add_child(UI.label("Camp bonus: you will find a free Healing Draught after resting.", 22, Pal.TURQUOISE, HORIZONTAL_ALIGNMENT_LEFT, true))
	var b := UI.button("Rest until dawn", "tent", "primary", Vector2(380, 70))
	b.pressed.connect(func():
		if game != null and game.has_method("rest_at_camp"):
			game.rest_at_camp()
		_msg.text = "You wake rested. Health and stamina restored. Game saved."
		_render())
	col.add_child(b)


func _ingredient_text(r: Dictionary) -> String:
	var parts: Array[String] = []
	var items: Dictionary = r["items"]
	for k in items:
		parts.append("%s %d/%d" % [Items.item(String(k)).name, GameState.count(String(k)), int(items[k])])
	if int(r.coins) > 0:
		parts.append("Coins %d/%d" % [GameState.coins, int(r.coins)])
	return "   ".join(parts)


func _render_craft(v: VBoxContainer) -> void:
	var sc := UI.scroll()
	v.add_child(sc)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 10)
	sc.add_child(list)
	for r in Items.RECIPES:
		var info := Items.item(String(r.out))
		var p := PanelContainer.new()
		var sb := UI.box(Color(0.05, 0.07, 0.13, 0.9), Pal.GOLD_DARK, 2, 10)
		sb.content_margin_left = 14
		sb.content_margin_right = 14
		sb.content_margin_top = 10
		sb.content_margin_bottom = 10
		p.add_theme_stylebox_override("panel", sb)
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 16)
		p.add_child(h)
		h.add_child(UI.icon(String(info.icon), 72, Pal.GOLD_LIGHT, true))
		var col := VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_theme_constant_override("separation", 2)
		h.add_child(col)
		var cnt := int(r.count) + (1 if r.out == "healing_draught" and GameState.camp_level >= 2 else 0)
		col.add_child(UI.label("%s%s" % [info.name, ("  x%d" % cnt) if cnt > 1 else ""], 27, Pal.GOLD_LIGHT))
		col.add_child(UI.label(String(info.desc), 20, Pal.TEXT_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))
		col.add_child(UI.label(_ingredient_text(r), 20, Pal.SAND, HORIZONTAL_ALIGNMENT_LEFT, true))
		var ok := GameState.can_afford({"coins": r.coins, "items": r["items"]})
		var b := UI.button("Craft", "hammer", "primary", Vector2(210, 64))
		b.disabled = not ok
		b.pressed.connect(func():
			if GameState.craft(String(r.id)):
				AudioMgr.play("craft")
				_msg.text = "Crafted: %s" % info.name
				_render())
		h.add_child(b)
		list.add_child(p)


func _render_storage(v: VBoxContainer) -> void:
	v.add_child(UI.label("Tap an item to move one between your backpack and the camp stash. Quest items and equipped gear cannot be stored.", 21, Pal.TEXT_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))
	var row := HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation", 24)
	v.add_child(row)
	for side in 2:
		var col := VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_theme_constant_override("separation", 8)
		row.add_child(col)
		col.add_child(UI.title("Backpack" if side == 0 else "Camp stash", 28, Pal.GOLD_LIGHT))
		var sc := UI.scroll()
		col.add_child(sc)
		var grid := GridContainer.new()
		grid.columns = 3
		grid.add_theme_constant_override("h_separation", 8)
		grid.add_theme_constant_override("v_separation", 8)
		sc.add_child(grid)
		var src: Dictionary = GameState.inventory if side == 0 else GameState.stash
		var any := false
		for id in src:
			var sid := String(id)
			var info := Items.item(sid)
			if side == 0 and (String(info.type) == "quest" or GameState.equipment.values().has(sid)):
				continue
			any = true
			var b := UI.button("", "", "normal", Vector2(150, 96))
			var ic := IconView.new(String(info.icon), 96)
			ic.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
			b.add_child(ic)
			var cl := UI.label("x%d" % int(src[id]), 20, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_RIGHT)
			cl.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
			cl.offset_left = -70
			cl.offset_top = -30
			cl.offset_right = -8
			cl.offset_bottom = -4
			cl.mouse_filter = Control.MOUSE_FILTER_IGNORE
			b.add_child(cl)
			b.pressed.connect(func():
				if GameState.stash_move(sid, side == 0):
					AudioMgr.play("pickup", -6.0)
					_render())
			grid.add_child(b)
		if not any:
			col.add_child(UI.label("Empty", 22, Pal.TEXT_DIM))
