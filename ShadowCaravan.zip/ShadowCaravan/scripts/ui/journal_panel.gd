extends "res://scripts/ui/panel_base.gd"
## Quest journal: the main quest with its stage checklist, the temple clue, and discovery stats.

const Items := preload("res://scripts/data/items.gd")

var _scroll_box: VBoxContainer


func _init() -> void:
	super("Quest Journal", Vector2(1100, 640))


func _build() -> void:
	var sc := UI.scroll()
	body.add_child(sc)
	_scroll_box = VBoxContainer.new()
	_scroll_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll_box.add_theme_constant_override("separation", 10)
	sc.add_child(_scroll_box)


func _step(done: bool, current: bool, text: String) -> Control:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	var ic := UI.icon("check" if done else ("interact" if current else "lock"), 36, Pal.TURQUOISE if done else (Pal.GOLD_LIGHT if current else Pal.DISABLED))
	h.add_child(ic)
	var col := Pal.TEXT_DIM if done else (Pal.TEXT if current else Pal.DISABLED)
	var l := UI.label(text, 24, col, HORIZONTAL_ALIGNMENT_LEFT, true)
	l.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(l)
	return h


func refresh() -> void:
	if _scroll_box == null:
		return
	for c in _scroll_box.get_children():
		c.queue_free()
	var qs := GameState.quest_stage
	_scroll_box.add_child(UI.title("The Lost Caravan", 40, Pal.GOLD_LIGHT))
	_scroll_box.add_child(UI.label("MAIN QUEST" + ("  -  COMPLETED" if GameState.quest_completed else ""), 20, Pal.TURQUOISE))
	_scroll_box.add_child(UI.label("Your caravan vanished into the Sunsea. Elder Sahir believes the Ancient Gate, sealed by three relic fragments, leads to the road the lost caravans took.", 23, Pal.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true))
	_scroll_box.add_child(UI.divider(16, Pal.GOLD_DARK))
	_scroll_box.add_child(_step(qs >= 1, qs == 0, "Speak with Elder Sahir at the Caravan Camp."))
	_scroll_box.add_child(_step(qs >= 2, qs == 1, "Recover the Relic Fragments (%d / %d)." % [GameState.fragments_found, Items.FRAGMENTS_REQUIRED]))
	var frag_lines := [
		["frag_alcove", "A fragment sealed in a hidden alcove among the dunes"],
		["frag_temple", "A fragment guarded by the Temple of Echoes' rune puzzle"],
		["frag_wraith", "A fragment held by the wraiths of Wraith Hollow"],
	]
	for f in frag_lines:
		var got := GameState.opened_ids.has(f[0])
		var l := UI.label(("   [x]  " if got else "   [ ]  ") + String(f[1]), 20, Pal.TURQUOISE if got else Pal.TEXT_DIM, HORIZONTAL_ALIGNMENT_LEFT, true)
		_scroll_box.add_child(l)
	_scroll_box.add_child(_step(qs >= 3, qs == 2, "Open the Ancient Gate to the north."))
	_scroll_box.add_child(_step(qs >= 4, qs == 3, "Defeat the Hollow Warden in the Lost Caravan ruins."))
	_scroll_box.add_child(_step(qs >= 5, qs == 4, "Claim the Ancient Relic."))
	_scroll_box.add_child(UI.divider(16, Pal.GOLD_DARK))
	_scroll_box.add_child(UI.title("Notes", 30, Pal.GOLD_LIGHT))
	if GameState.clue_found:
		_scroll_box.add_child(UI.label(Items.PUZZLE_CLUE, 23, Pal.SAND, HORIZONTAL_ALIGNMENT_LEFT, true))
	else:
		_scroll_box.add_child(UI.label("Elder Sahir mentioned a weeping stone near the ruins that remembers an old rite.", 22, Pal.TEXT_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))
	if GameState.puzzle_solved:
		_scroll_box.add_child(UI.label("The Temple of Echoes answered your rune sequence.", 22, Pal.TURQUOISE, HORIZONTAL_ALIGNMENT_LEFT, true))
	_scroll_box.add_child(UI.divider(16, Pal.GOLD_DARK))
	_scroll_box.add_child(UI.title("Discoveries", 30, Pal.GOLD_LIGHT))
	var disc := 0
	for id in Items.LOCATIONS:
		if GameState.is_discovered(String(id)):
			disc += 1
	_scroll_box.add_child(UI.label("Locations found: %d / %d" % [disc, Items.LOCATIONS.size()], 23, Pal.TEXT))
	_scroll_box.add_child(UI.label("Treasure chests opened: %d / %d" % [GameState.chests_opened(), Items.CHESTS.size()], 23, Pal.TEXT))
	_scroll_box.add_child(UI.label("Enemies defeated: %d" % GameState.kills, 23, Pal.TEXT))
