extends "res://scripts/ui/panel_base.gd"
## Inventory & equipment: filter tabs, item grid with icons/counts, detail pane with Equip / Use,
## plus the two equipment slots (weapon, armor).

const Items := preload("res://scripts/data/items.gd")
const IconView := preload("res://scripts/ui/icon_view.gd")

const FILTERS := {"all": "All", "gear": "Gear", "use": "Supplies", "mat": "Materials"}

var _filter := "all"
var _selected := ""
var _grid: GridContainer
var _tabs: Dictionary = {}
var _d_icon: IconView
var _d_name: Label
var _d_type: Label
var _d_desc: Label
var _d_stat: Label
var _btn_main: Button
var _eq_weapon: Label
var _eq_armor: Label
var _eq_weapon_icon: IconView
var _eq_armor_icon: IconView
var _empty: Label


func _init() -> void:
	super("Inventory", Vector2(1160, 640))


func _build() -> void:
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 10)
	for k in FILTERS:
		var b := UI.button(FILTERS[k], "", "tab", Vector2(180, 56))
		b.add_theme_font_size_override("font_size", 23)
		b.pressed.connect(_set_filter.bind(String(k)))
		tabs.add_child(b)
		_tabs[k] = b
	body.add_child(tabs)
	var row := HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation", 24)
	body.add_child(row)
	# left: grid
	var sc := UI.scroll()
	sc.custom_minimum_size = Vector2(560, 0)
	row.add_child(sc)
	var holder := VBoxContainer.new()
	holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(holder)
	_grid = GridContainer.new()
	_grid.columns = 5
	_grid.add_theme_constant_override("h_separation", 10)
	_grid.add_theme_constant_override("v_separation", 10)
	holder.add_child(_grid)
	_empty = UI.label("Nothing here yet.", 24, Pal.TEXT_DIM)
	holder.add_child(_empty)
	# right: detail
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 8)
	row.add_child(right)
	var eq := HBoxContainer.new()
	eq.add_theme_constant_override("separation", 16)
	var w := _equip_slot("sword", "Weapon")
	_eq_weapon_icon = w[0]
	_eq_weapon = w[1]
	eq.add_child(w[2])
	var a := _equip_slot("cloak", "Armor")
	_eq_armor_icon = a[0]
	_eq_armor = a[1]
	eq.add_child(a[2])
	right.add_child(eq)
	right.add_child(UI.divider(14, Pal.GOLD_DARK))
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 14)
	_d_icon = UI.icon("", 88, Pal.GOLD_LIGHT, true)
	head.add_child(_d_icon)
	var hv := VBoxContainer.new()
	hv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_d_name = UI.title("", 32, Pal.GOLD_LIGHT)
	_d_type = UI.label("", 20, Pal.TURQUOISE)
	_d_stat = UI.label("", 22, Pal.SAND)
	hv.add_child(_d_name)
	hv.add_child(_d_type)
	hv.add_child(_d_stat)
	head.add_child(hv)
	right.add_child(head)
	_d_desc = UI.label("", 23, Pal.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true)
	_d_desc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(_d_desc)
	_btn_main = UI.button("", "", "primary", Vector2(0, 64))
	_btn_main.pressed.connect(_main_action)
	right.add_child(_btn_main)
	GameState.inventory_changed.connect(_on_changed)


func _exit_tree() -> void:
	if GameState.inventory_changed.is_connected(_on_changed):
		GameState.inventory_changed.disconnect(_on_changed)


func _on_changed() -> void:
	if is_open:
		refresh()


func _equip_slot(icon: String, title: String) -> Array:
	var p := PanelContainer.new()
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var sb := UI.box(Color(0.05, 0.07, 0.13, 0.9), Pal.GOLD_DARK, 2, 10)
	sb.content_margin_left = 10
	sb.content_margin_right = 10
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	p.add_theme_stylebox_override("panel", sb)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 10)
	p.add_child(h)
	var ic := UI.icon(icon, 60, Pal.GOLD_LIGHT, true)
	h.add_child(ic)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(UI.label(title.to_upper(), 16, Pal.TEXT_DIM))
	var name_l := UI.label("-", 21, Pal.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true)
	v.add_child(name_l)
	h.add_child(v)
	return [ic, name_l, p]


func _set_filter(k: String) -> void:
	_filter = k
	_selected = ""
	refresh()


func _matches(id: String) -> bool:
	var t := String(Items.item(id).type)
	match _filter:
		"gear":
			return t == "weapon" or t == "armor"
		"use":
			return t == "consumable" or t == "quest"
		"mat":
			return t == "material"
	return true


func refresh() -> void:
	if _grid == null:
		return
	for k in _tabs:
		_tabs[k].set_pressed_no_signal(k == _filter)
	for c in _grid.get_children():
		c.queue_free()
	var ids: Array = []
	for id in GameState.inventory:
		if _matches(String(id)):
			ids.append(String(id))
	ids.sort_custom(func(a: String, b: String): return String(Items.item(a).type) + a < String(Items.item(b).type) + b)
	_empty.visible = ids.is_empty()
	if _selected == "" or not ids.has(_selected):
		_selected = ids[0] if ids.size() > 0 else ""
	for id in ids:
		_grid.add_child(_slot(id))
	_update_equipped()
	_update_detail()


func _slot(id: String) -> Control:
	var info := Items.item(id)
	var b := UI.button("", "", "tab", Vector2(98, 98))
	b.set_pressed_no_signal(id == _selected)
	b.pressed.connect(func():
		_selected = id
		refresh())
	var ic := IconView.new(String(info.icon), 98)
	ic.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	b.add_child(ic)
	var n := GameState.count(id)
	if n > 1 or String(info.type) == "material" or String(info.type) == "consumable":
		var cl := UI.label("x%d" % n, 20, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_RIGHT)
		cl.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
		cl.offset_left = -60
		cl.offset_top = -30
		cl.offset_right = -8
		cl.offset_bottom = -4
		cl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(cl)
	if GameState.equipment.values().has(id):
		var e := UI.label("E", 18, Pal.TURQUOISE)
		e.position = Vector2(8, 4)
		e.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(e)
	return b


func _update_equipped() -> void:
	var w := String(GameState.equipment.get("weapon", ""))
	var a := String(GameState.equipment.get("armor", ""))
	_eq_weapon.text = "%s (%d dmg)" % [Items.item(w).name, int(GameState.weapon_damage())] if w != "" else "None"
	_eq_armor.text = "%s (-%d dmg)" % [Items.item(a).name, int(GameState.armor_defense())] if a != "" else "None"
	_eq_weapon_icon.set_icon(String(Items.item(w).icon) if w != "" else "", Pal.GOLD_LIGHT)
	_eq_armor_icon.set_icon(String(Items.item(a).icon) if a != "" else "", Pal.GOLD_LIGHT)


func _update_detail() -> void:
	if _selected == "":
		_d_icon.set_icon("")
		_d_name.text = ""
		_d_type.text = ""
		_d_stat.text = ""
		_d_desc.text = "Select an item to see details."
		_btn_main.visible = false
		return
	var info := Items.item(_selected)
	_d_icon.set_icon(String(info.icon))
	_d_name.text = String(info.name)
	_d_type.text = String(info.type).to_upper() + "  x%d" % GameState.count(_selected)
	_d_desc.text = String(info.desc)
	_d_stat.text = ""
	var t := String(info.type)
	_btn_main.visible = true
	_btn_main.disabled = false
	match t:
		"weapon", "armor":
			if t == "weapon":
				_d_stat.text = "Damage %d" % int(info.dmg)
			else:
				_d_stat.text = "Defense %d" % int(info.def)
			if GameState.equipment.get(t, "") == _selected:
				_btn_main.text = "Equipped"
				_btn_main.disabled = true
			else:
				_btn_main.text = "Equip"
		"consumable":
			_btn_main.text = "Use (+%d health)" % int(info.get("heal", 0))
			_btn_main.disabled = GameState.hp >= GameState.max_hp() - 0.01
		_:
			_btn_main.visible = false


func _main_action() -> void:
	if _selected == "":
		return
	var t := String(Items.item(_selected).type)
	if t == "weapon" or t == "armor":
		if GameState.equip(_selected):
			AudioMgr.play("pickup")
	elif t == "consumable":
		GameState.use_item(_selected)
	refresh()
