extends "res://scripts/ui/panel_base.gd"
## Temple of Echoes rune puzzle. Three dials cycle through Sun / Moon / Eye / Serpent.
## The solution is hinted by the Weeping Stone tablet (found elsewhere in the world).
## Valid / invalid states are reported; progress and completion are saved through GameState.

const Items := preload("res://scripts/data/items.gd")
const Icons := preload("res://scripts/ui/icons.gd")
const IconView := preload("res://scripts/ui/icon_view.gd")

signal solved

var _dials: Array[Button] = []
var _runes: Array[IconView] = []
var _names: Array[Label] = []
var _status: Label
var _clue: Label
var _attune: Button
var _locked := false


func _init() -> void:
	super("Runes of Echoes", Vector2(1100, 668))


func _build() -> void:
	body.add_child(UI.label(Items.PUZZLE_HINT, 22, Pal.TEXT, HORIZONTAL_ALIGNMENT_CENTER, true))
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 40)
	body.add_child(row)
	for i in 3:
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 6)
		var b := UI.button("", "", "normal", Vector2(190, 140))
		b.pressed.connect(_turn.bind(i))
		var rv := IconView.new("", 140)
		rv.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		b.add_child(rv)
		col.add_child(b)
		var nl := UI.label("", 24, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER)
		col.add_child(nl)
		row.add_child(col)
		_dials.append(b)
		_runes.append(rv)
		_names.append(nl)
	_status = UI.label("", 25, Pal.SAND, HORIZONTAL_ALIGNMENT_CENTER, true)
	_status.custom_minimum_size = Vector2(0, 36)
	body.add_child(_status)
	var cp := PanelContainer.new()
	cp.add_theme_stylebox_override("panel", UI.box(Color(0.05, 0.07, 0.13, 0.9), Pal.TURQUOISE_DIM, 2, 10))
	_clue = UI.label("", 21, Pal.SAND, HORIZONTAL_ALIGNMENT_CENTER, true)
	cp.add_child(UI.pad(_clue, 14, 8, 14, 10))
	body.add_child(cp)
	body.add_child(UI.hfill())
	var btns := HBoxContainer.new()
	btns.alignment = BoxContainer.ALIGNMENT_CENTER
	btns.add_theme_constant_override("separation", 26)
	var reset := UI.button("Reset runes", "roll", "normal", Vector2(290, 66))
	reset.pressed.connect(_reset)
	_attune = UI.button("Attune", "relic", "primary", Vector2(330, 66))
	_attune.pressed.connect(_attune_pressed)
	btns.add_child(reset)
	btns.add_child(_attune)
	body.add_child(btns)


func refresh() -> void:
	_locked = GameState.puzzle_solved
	_clue.text = Items.PUZZLE_CLUE if GameState.clue_found else "You have not found a clue yet. Search the ruins east of the Broken Court for an old carved stone."
	_status.text = "The runes are attuned. The way is open." if _locked else "The pillars are dormant."
	_status.add_theme_color_override("font_color", Pal.TURQUOISE if _locked else Pal.SAND)
	_attune.disabled = _locked
	_update_dials()


func _update_dials() -> void:
	for i in 3:
		var idx := int(GameState.puzzle_dials[i])
		_runes[i].set_rune(idx, Pal.TURQUOISE if _locked else Pal.TURQUOISE.lerp(Pal.GOLD_LIGHT, 0.0))
		_names[i].text = String(Icons.RUNE_NAMES[idx])
		_dials[i].disabled = _locked


func _turn(i: int) -> void:
	if _locked:
		return
	GameState.puzzle_dials[i] = (int(GameState.puzzle_dials[i]) + 1) % 4
	AudioMgr.play("stone_turn", -4.0, randf_range(0.9, 1.1))
	Controls.vibrate(25)
	_status.text = "The pillars are dormant."
	_status.add_theme_color_override("font_color", Pal.SAND)
	var tw := create_tween()
	_runes[i].pivot_offset = _runes[i].size * 0.5
	_runes[i].scale = Vector2(0.8, 0.8)
	tw.tween_property(_runes[i], "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_update_dials()
	GameState.stats_changed.emit()


func _reset() -> void:
	if _locked:
		return
	GameState.puzzle_dials = [0, 0, 0]
	_status.text = "The runes return to their first positions."
	_update_dials()


## Returns how many dials already match the solution (0..3).
func correct_count() -> int:
	var n := 0
	for i in 3:
		if int(GameState.puzzle_dials[i]) == int(Items.PUZZLE_SOLUTION[i]):
			n += 1
	return n


func _attune_pressed() -> void:
	if _locked:
		return
	var n := correct_count()
	if n == 3:
		_locked = true
		GameState.puzzle_solved = true
		AudioMgr.play("puzzle_ok")
		Controls.vibrate(120)
		_status.text = "The runes blaze turquoise. Somewhere, stone grinds open."
		_status.add_theme_color_override("font_color", Pal.TURQUOISE)
		_attune.disabled = true
		_update_dials()
		solved.emit()
		await get_tree().create_timer(1.6).timeout
		if is_open:
			close()
	else:
		AudioMgr.play("puzzle_fail")
		Controls.vibrate(60)
		var msg := "The runes flicker and fade. The pillars stay dormant."
		if n > 0:
			msg += "  (%d of 3 hum in harmony)" % n
		_status.text = msg
		_status.add_theme_color_override("font_color", Color("f0a09c"))
		var tw := create_tween()
		for k in 4:
			tw.tween_property(frame, "position:x", frame.position.x + (10 if k % 2 == 0 else -10), 0.04)
		tw.tween_property(frame, "position:x", frame.position.x, 0.04)
