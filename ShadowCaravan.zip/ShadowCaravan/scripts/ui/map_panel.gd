extends "res://scripts/ui/panel_base.gd"
## World map: hill-shaded terrain with fog of war, discovered locations, the player marker and the
## current objective. Tap a location for details; waystones can be used to fast-travel when the map
## was opened from a waystone.

const Items := preload("res://scripts/data/items.gd")
const Icons := preload("res://scripts/ui/icons.gd")
const Terrain := preload("res://scripts/world/terrain.gd")

signal travel_requested(loc_id: String)

var game: Node
var travel_mode := false
var _view: Control
var _selected := ""
var _name: Label
var _desc: Label
var _state: Label
var _travel: Button
var _fog: ImageTexture
var _fog_key := ""


class MapView extends Control:
	var panel: Node
	var _t := 0.0

	func _process(delta: float) -> void:
		if is_visible_in_tree():
			_t += delta
			queue_redraw()

	func to_screen(wx: float, wz: float) -> Vector2:
		return Vector2((wx + 100.0) / 200.0 * size.x, (wz + 100.0) / 200.0 * size.y)

	func _gui_input(event: InputEvent) -> void:
		var p := Vector2.ZERO
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			p = event.position
		elif event is InputEventScreenTouch and event.pressed:
			p = event.position
		else:
			return
		var best := ""
		var best_d := 46.0
		for id in Items.LOCATIONS:
			if not GameState.is_discovered(String(id)):
				continue
			var lp: Vector2 = Items.LOCATIONS[id].pos
			var d := to_screen(lp.x, lp.y).distance_to(p)
			if d < best_d:
				best_d = d
				best = String(id)
		if best != "":
			panel.select(best)

	func _draw() -> void:
		var r := Rect2(Vector2.ZERO, size)
		draw_texture_rect(Terrain.map_texture(), r, false)
		var fog: Texture2D = panel.get_fog()
		if fog != null:
			draw_texture_rect(fog, r, false)
		draw_rect(r, Color(Pal.GOLD, 0.9), false, 3.0)
		# fine grid
		for i in range(1, 4):
			var u := float(i) / 4.0
			draw_line(Vector2(u * size.x, 0), Vector2(u * size.x, size.y), Color(0, 0, 0, 0.12), 1.0)
			draw_line(Vector2(0, u * size.y), Vector2(size.x, u * size.y), Color(0, 0, 0, 0.12), 1.0)
		# the sealed gate line
		var g0 := to_screen(-100.0, Items.LOCATIONS.gate.pos.y)
		var g1 := to_screen(100.0, Items.LOCATIONS.gate.pos.y)
		if GameState.is_discovered("gate"):
			draw_line(g0, g1, Color(Pal.BLOOD if not GameState.gate_open else Pal.TURQUOISE, 0.5), 2.0)
		# locations
		for id in Items.LOCATIONS:
			var sid := String(id)
			if not GameState.is_discovered(sid):
				continue
			var info: Dictionary = Items.LOCATIONS[id]
			var sp := to_screen(info.pos.x, info.pos.y)
			var sel: bool = sid == panel._selected
			var icon := "waystone" if bool(info.waystone) else "star"
			if sid == "camp":
				icon = "camp"
			draw_circle(sp, 17.0 if sel else 14.0, Color(0.04, 0.05, 0.1, 0.85))
			draw_arc(sp, 17.0 if sel else 14.0, 0, TAU, 24, Pal.TURQUOISE if sel else Pal.GOLD, 2.5, true)
			Icons.draw_icon(self, icon, sp, 8.5, Pal.GOLD_LIGHT)
		# objective
		var pl: Node3D = GameState.player_ref
		var from := pl.global_position if is_instance_valid(pl) else Vector3.ZERO
		for t in GameState.objective_targets(from):
			var tp := to_screen(t.x, t.z)
			var s := 11.0 + 2.5 * sin(_t * 4.0)
			draw_colored_polygon(PackedVector2Array([tp + Vector2(0, -s), tp + Vector2(s, 0), tp + Vector2(0, s), tp + Vector2(-s, 0)]), Pal.TURQUOISE)
			draw_arc(tp, s + 5.0, 0, TAU, 20, Color(Pal.TURQUOISE, 0.55), 2.0, true)
		# player arrow
		if is_instance_valid(pl):
			var pp := to_screen(pl.global_position.x, pl.global_position.z)
			var yaw: float = pl.rotation.y
			var fwd := Vector2(-sin(yaw), -cos(yaw))
			var side := Vector2(-fwd.y, fwd.x)
			draw_colored_polygon(PackedVector2Array([pp + fwd * 15.0, pp - fwd * 9.0 + side * 9.0, pp - fwd * 4.0, pp - fwd * 9.0 - side * 9.0]), Pal.BLOOD)
			draw_polyline(PackedVector2Array([pp + fwd * 15.0, pp - fwd * 9.0 + side * 9.0, pp - fwd * 4.0, pp - fwd * 9.0 - side * 9.0, pp + fwd * 15.0]), Color(1, 1, 1, 0.9), 2.0)
		# compass rose
		var f := ThemeDB.fallback_font
		draw_string(f, Vector2(size.x * 0.5 - 8, 24), "N", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Pal.OBSIDIAN)


func _init() -> void:
	super("World Map", Vector2(1160, 650))


func _build() -> void:
	var row := HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation", 26)
	body.add_child(row)
	var wrap := CenterContainer.new()
	row.add_child(wrap)
	_view = MapView.new()
	_view.panel = self
	_view.custom_minimum_size = Vector2(500, 500)
	_view.mouse_filter = Control.MOUSE_FILTER_STOP
	wrap.add_child(_view)
	var side := VBoxContainer.new()
	side.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	side.add_theme_constant_override("separation", 10)
	row.add_child(side)
	_name = UI.title("", 36, Pal.GOLD_LIGHT)
	_name.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	side.add_child(_name)
	_state = UI.label("", 21, Pal.TURQUOISE)
	side.add_child(_state)
	_desc = UI.label("", 23, Pal.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true)
	_desc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	side.add_child(_desc)
	var legend := VBoxContainer.new()
	legend.add_theme_constant_override("separation", 4)
	for e in [["Red arrow", "You", Pal.BLOOD], ["Turquoise diamond", "Current objective", Pal.TURQUOISE], ["Waystone icon", "Fast-travel point", Pal.GOLD_LIGHT]]:
		legend.add_child(UI.label("%s - %s" % [e[0], e[1]], 19, e[2]))
	side.add_child(legend)
	_travel = UI.button("Travel here", "travel", "primary", Vector2(0, 66))
	_travel.pressed.connect(_do_travel)
	side.add_child(_travel)


func get_fog() -> Texture2D:
	var key := ",".join(GameState.discovered_ids)
	if key != _fog_key or _fog == null:
		_fog_key = key
		var res := 64
		var img := Image.create(res, res, false, Image.FORMAT_RGBA8)
		for py in res:
			for px in res:
				var x := -100.0 + (float(px) + 0.5) / float(res) * 200.0
				var z := -100.0 + (float(py) + 0.5) / float(res) * 200.0
				var open := 0.0
				for id in GameState.discovered_ids:
					var info: Dictionary = Items.LOCATIONS.get(String(id), {})
					if info.is_empty():
						continue
					var d := Vector2(x, z).distance_to(info.pos)
					open = maxf(open, 1.0 - smoothstep(float(info.radius) * 0.9, float(info.radius) * 0.9 + 26.0, d))
				img.set_pixel(px, py, Color(0.04, 0.06, 0.12, 0.8 * (1.0 - open)))
		_fog = ImageTexture.create_from_image(img)
	return _fog


func open_map(travel: bool) -> void:
	travel_mode = travel
	open()


func select(id: String) -> void:
	_selected = id
	AudioMgr.play("ui_click")
	_update_info()


func refresh() -> void:
	if _selected == "" or not GameState.is_discovered(_selected):
		_selected = GameState.checkpoint_id if GameState.is_discovered(GameState.checkpoint_id) else "camp"
	_update_info()
	_view.queue_redraw()


func _update_info() -> void:
	if _selected == "":
		return
	var info: Dictionary = Items.LOCATIONS[_selected]
	_name.text = String(info.name)
	_desc.text = String(info.desc)
	var tags: Array[String] = []
	tags.append("WAYSTONE" if bool(info.waystone) else "LANDMARK")
	if _selected == GameState.checkpoint_id:
		tags.append("CHECKPOINT")
	_state.text = "  |  ".join(tags)
	var can_travel: bool = bool(info.waystone) and travel_mode and (game == null or game.has_method("can_fast_travel") and game.can_fast_travel())
	_travel.visible = bool(info.waystone)
	_travel.disabled = not can_travel
	if not bool(info.waystone):
		_travel.text = ""
	elif travel_mode:
		_travel.text = "Travel here"
	else:
		_travel.text = "Use a waystone to travel"


func _do_travel() -> void:
	if _selected == "":
		return
	var id := _selected
	close()
	travel_requested.emit(id)
