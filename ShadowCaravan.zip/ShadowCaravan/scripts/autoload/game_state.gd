extends Node
## Global game state: progression, inventory, quest, puzzle, settings and the save system.
## The save file is JSON wrapped in an integrity envelope ({v, sha, payload}); writes are atomic
## (tmp file -> verified -> backup of the old save -> rename) and loads fall back to the backup.

const Items := preload("res://scripts/data/items.gd")

const SAVE_VERSION := 1
const DEFAULT_SAVE_PATH := "user://shadow_caravan_save.json"
const SETTINGS_PATH := "user://shadow_caravan_settings.cfg"

signal inventory_changed
signal stats_changed
signal quest_changed
signal toast(text: String, kind: String)
signal level_up(new_level: int)
signal location_discovered(loc_id: String)
signal settings_changed
signal game_saved
signal quest_completed_event

var save_path := DEFAULT_SAVE_PATH  # tests override this

# ----- persistent progression -----
var hp := 100.0
var level := 1
var xp := 0
var coins := 0
var kills := 0
var inventory: Dictionary = {}
var equipment := {"weapon": "worn_scimitar", "armor": "travelers_wraps"}
var upgrades := {"vitality": 0, "blade": 0, "endurance": 0}
var camp_level := 1
var stash: Dictionary = {}
var quest_stage := 0
var fragments_found := 0
var gate_open := false
var boss_defeated := false
var quest_completed := false
var puzzle_dials: Array = [0, 0, 0]
var puzzle_solved := false
var clue_found := false
var discovered_ids: Array = []
var opened_ids: Array = []
var checkpoint_id := "camp"
var player_pos := Vector3.ZERO
var player_yaw := 0.0
var has_position := false
var play_time := 0.0
var intro_seen := false

# ----- runtime only -----
var stamina := 100.0
var session_active := false
var player_ref: Node3D = null
var last_load_message := ""

# ----- settings (stored separately so Reset Save keeps them) -----
var music_volume := 0.7
var sfx_volume := 0.9
var quality := 1  # 0 low, 1 medium, 2 high
var look_sensitivity := 1.0
var invert_y := false
var haptics := true


func _ready() -> void:
	load_settings()


func _process(delta: float) -> void:
	if session_active:
		play_time += delta


# =============================================================== derived stats
func max_hp() -> float:
	return 100.0 + float(upgrades.get("vitality", 0)) * 15.0 + float(level - 1) * 5.0


func max_stamina() -> float:
	return 100.0 + float(upgrades.get("endurance", 0)) * 10.0


func weapon_damage() -> float:
	var w: Dictionary = Items.item(String(equipment.get("weapon", "")))
	return float(w.get("dmg", 6)) + float(upgrades.get("blade", 0)) * 3.0


func armor_defense() -> float:
	var a: Dictionary = Items.item(String(equipment.get("armor", "")))
	return float(a.get("def", 0))


# =============================================================== inventory
func count(id: String) -> int:
	return int(inventory.get(id, 0))


func has_items(req: Dictionary) -> bool:
	for k in req:
		if count(String(k)) < int(req[k]):
			return false
	return true


func add_item(id: String, n: int = 1, quiet: bool = false) -> void:
	if n <= 0 or not Items.ITEMS.has(id):
		return
	inventory[id] = count(id) + n
	if not quiet:
		toast.emit("Acquired: %s x%d" % [Items.item(id).name, n], "item")
	inventory_changed.emit()


func remove_item(id: String, n: int = 1) -> bool:
	if count(id) < n:
		return false
	inventory[id] = count(id) - n
	if int(inventory[id]) <= 0:
		inventory.erase(id)
		# Un-equip if the last copy of an equipped item was removed.
		for slot in equipment:
			if equipment[slot] == id:
				equipment[slot] = ""
	inventory_changed.emit()
	stats_changed.emit()
	return true


func add_coins(n: int, quiet: bool = false) -> void:
	coins += n
	if not quiet and n > 0:
		toast.emit("+%d coins" % n, "item")
	stats_changed.emit()


func spend(cost: Dictionary) -> bool:
	var c: int = int(cost.get("coins", 0))
	var items: Dictionary = cost.get("items", {})
	if coins < c or not has_items(items):
		return false
	coins -= c
	for k in items:
		remove_item(String(k), int(items[k]))
	stats_changed.emit()
	return true


func can_afford(cost: Dictionary) -> bool:
	return coins >= int(cost.get("coins", 0)) and has_items(cost.get("items", {}))


func equip(id: String) -> bool:
	var it: Dictionary = Items.item(id)
	var t: String = String(it.get("type", ""))
	if (t != "weapon" and t != "armor") or count(id) <= 0:
		return false
	equipment[t] = id
	toast.emit("Equipped: %s" % it.name, "info")
	stats_changed.emit()
	inventory_changed.emit()
	return true


func use_item(id: String) -> bool:
	var it: Dictionary = Items.item(id)
	if String(it.get("type", "")) != "consumable" or count(id) <= 0:
		return false
	if hp >= max_hp() - 0.01:
		toast.emit("You are already at full health.", "warn")
		return false
	remove_item(id, 1)
	heal(float(it.get("heal", 0)))
	toast.emit("%s used: +%d health" % [it.name, int(it.get("heal", 0))], "info")
	AudioMgr.play("heal")
	return true


func heal(amount: float) -> void:
	hp = minf(max_hp(), hp + amount)
	stats_changed.emit()


func add_xp(n: int) -> void:
	xp += n
	var leveled := false
	while xp >= Items.xp_for_next(level):
		xp -= Items.xp_for_next(level)
		level += 1
		leveled = true
	if leveled:
		hp = max_hp()
		toast.emit("Level up! You are now level %d." % level, "quest")
		level_up.emit(level)
	stats_changed.emit()


func buy_upgrade(id: String) -> bool:
	var rank: int = int(upgrades.get(id, 0))
	var info: Dictionary = Items.UPGRADES.get(id, {})
	if info.is_empty() or rank >= int(info.max):
		return false
	var cost := Items.upgrade_cost(id, rank)
	if not spend(cost):
		toast.emit("Not enough resources.", "warn")
		return false
	upgrades[id] = rank + 1
	if id == "vitality":
		hp = minf(max_hp(), hp + 15.0)
	toast.emit("%s upgraded to rank %d" % [info.name, rank + 1], "quest")
	stats_changed.emit()
	return true


func upgrade_camp() -> bool:
	if camp_level >= Items.CAMP_MAX_LEVEL:
		return false
	if not spend(Items.camp_upgrade_cost(camp_level)):
		toast.emit("Not enough resources.", "warn")
		return false
	camp_level += 1
	toast.emit("Caravan Camp upgraded to level %d" % camp_level, "quest")
	stats_changed.emit()
	return true


func craft(recipe_id: String) -> bool:
	for r in Items.RECIPES:
		if r.id == recipe_id:
			var cost := {"coins": r.coins, "items": r["items"]}
			if not spend(cost):
				toast.emit("Missing ingredients.", "warn")
				return false
			var n: int = int(r.count)
			if r.out == "healing_draught" and camp_level >= 2:
				n += 1
			add_item(String(r.out), n)
			return true
	return false


func stash_move(id: String, to_stash: bool) -> bool:
	if to_stash:
		if count(id) <= 0 or String(Items.item(id).type) == "quest" or equipment.values().has(id):
			return false
		remove_item(id, 1)
		stash[id] = int(stash.get(id, 0)) + 1
	else:
		if int(stash.get(id, 0)) <= 0:
			return false
		stash[id] = int(stash[id]) - 1
		if int(stash[id]) <= 0:
			stash.erase(id)
		add_item(id, 1, true)
	inventory_changed.emit()
	return true


# =============================================================== quest
func accept_quest() -> void:
	if quest_stage == 0:
		quest_stage = 1
		toast.emit("Quest started: The Lost Caravan", "quest")
		AudioMgr.play("quest_accept")
		quest_changed.emit()


func collect_fragment(source_id: String) -> void:
	if opened_ids.has(source_id):
		return
	opened_ids.append(source_id)
	fragments_found += 1
	add_item("relic_fragment", 1, true)
	toast.emit("Relic Fragment found (%d/%d)" % [fragments_found, Items.FRAGMENTS_REQUIRED], "quest")
	if fragments_found >= Items.FRAGMENTS_REQUIRED and quest_stage <= 1:
		quest_stage = 2
		toast.emit("The Ancient Gate awaits.", "quest")
	elif quest_stage == 0:
		quest_stage = 1
	quest_changed.emit()


func open_gate() -> bool:
	if gate_open:
		return true
	if count("relic_fragment") < Items.FRAGMENTS_REQUIRED:
		return false
	remove_item("relic_fragment", Items.FRAGMENTS_REQUIRED)
	gate_open = true
	quest_stage = 3
	toast.emit("The Ancient Gate grinds open...", "quest")
	quest_changed.emit()
	return true


func on_boss_defeated() -> void:
	if boss_defeated:
		return
	boss_defeated = true
	kills += 1
	add_xp(int(Items.XP_VALUES.boss))
	quest_stage = maxi(quest_stage, 4)
	toast.emit("The Hollow Warden crumbles. Claim the Ancient Relic!", "quest")
	quest_changed.emit()


func complete_quest() -> void:
	if quest_completed:
		return
	quest_completed = true
	quest_stage = 5
	add_coins(250, true)
	add_item("caravan_blade", 1, true)
	add_xp(int(Items.XP_VALUES.quest))
	quest_changed.emit()
	quest_completed_event.emit()


func objective_text() -> String:
	match quest_stage:
		0:
			return "Speak with Elder Sahir at the Caravan Camp."
		1:
			return "Recover the Relic Fragments (%d/%d)" % [fragments_found, Items.FRAGMENTS_REQUIRED]
		2:
			return "Open the Ancient Gate to the north."
		3:
			return "Defeat the Hollow Warden in the Lost Caravan ruins."
		4:
			return "Claim the Ancient Relic."
	return "The Lost Caravan is found. Explore freely."


## World-space marker positions for the compass / map for the current objective.
func objective_targets(from: Vector3) -> Array:
	var out: Array = []
	match quest_stage:
		0:
			out.append(Vector3(-60, 0, 52))
		1:
			var cands := {"frag_alcove": Vector3(14, 0, -8), "frag_temple": Vector3(52, 0, -12), "frag_wraith": Vector3(-52, 0, -26)}
			var best := Vector3.ZERO
			var best_d := INF
			for k in cands:
				if opened_ids.has(k):
					continue
				var d: float = from.distance_to(cands[k])
				if d < best_d:
					best_d = d
					best = cands[k]
			if best_d < INF:
				out.append(best)
		2:
			out.append(Vector3(0, 0, -56))
		3:
			out.append(Vector3(0, 0, -86))
		4:
			out.append(Vector3(0, 0, -98))
	return out


func is_discovered(id: String) -> bool:
	return discovered_ids.has(id)


func discover(id: String, silent: bool = false) -> void:
	if discovered_ids.has(id) or not Items.LOCATIONS.has(id):
		return
	discovered_ids.append(id)
	if not silent:
		toast.emit("Discovered: %s" % Items.LOCATIONS[id].name, "quest")
		if id != "camp":
			add_xp(int(Items.XP_VALUES.discovery))
	location_discovered.emit(id)


func chests_opened() -> int:
	var n := 0
	for k in Items.CHESTS:
		if opened_ids.has(k):
			n += 1
	return n


# =============================================================== lifecycle
func new_game() -> void:
	hp = 100.0
	level = 1
	xp = 0
	coins = 0
	kills = 0
	inventory = {"worn_scimitar": 1, "travelers_wraps": 1, "healing_draught": 1}
	equipment = {"weapon": "worn_scimitar", "armor": "travelers_wraps"}
	upgrades = {"vitality": 0, "blade": 0, "endurance": 0}
	camp_level = 1
	stash = {}
	quest_stage = 0
	fragments_found = 0
	gate_open = false
	boss_defeated = false
	quest_completed = false
	puzzle_dials = [0, 0, 0]
	puzzle_solved = false
	clue_found = false
	discovered_ids = []
	opened_ids = []
	checkpoint_id = "camp"
	player_pos = Vector3.ZERO
	player_yaw = 0.0
	has_position = false
	play_time = 0.0
	intro_seen = false
	stamina = max_stamina()
	session_active = true
	discovered_ids.append("camp")
	inventory_changed.emit()
	stats_changed.emit()
	quest_changed.emit()


# =============================================================== save / load
func has_save() -> bool:
	return FileAccess.file_exists(save_path) or FileAccess.file_exists(save_path + ".bak")


func _payload() -> Dictionary:
	return {
		"hp": hp, "level": level, "xp": xp, "coins": coins, "kills": kills,
		"inventory": inventory, "equipment": equipment, "upgrades": upgrades,
		"camp_level": camp_level, "stash": stash,
		"quest_stage": quest_stage, "fragments_found": fragments_found, "gate_open": gate_open,
		"boss_defeated": boss_defeated, "quest_completed": quest_completed,
		"puzzle_dials": puzzle_dials, "puzzle_solved": puzzle_solved, "clue_found": clue_found,
		"discovered": discovered_ids, "opened": opened_ids, "checkpoint": checkpoint_id,
		"pos": [player_pos.x, player_pos.y, player_pos.z], "yaw": player_yaw, "has_pos": has_position,
		"play_time": play_time, "intro_seen": intro_seen,
	}


func save_game() -> bool:
	if is_instance_valid(player_ref) and player_ref.is_inside_tree():
		player_pos = player_ref.global_position
		player_yaw = player_ref.rotation.y
		has_position = true
	var payload_str := JSON.stringify(_payload())
	var envelope := JSON.stringify({"v": SAVE_VERSION, "sha": payload_str.sha256_text(), "payload": payload_str})
	var tmp := save_path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		push_warning("Save failed: cannot open %s (error %d)" % [tmp, FileAccess.get_open_error()])
		return false
	f.store_string(envelope)
	f.close()
	if _read_envelope(tmp).is_empty():
		push_warning("Save failed: verification of temp file failed")
		DirAccess.remove_absolute(tmp)
		return false
	if FileAccess.file_exists(save_path):
		DirAccess.copy_absolute(save_path, save_path + ".bak")
		DirAccess.remove_absolute(save_path)
	var err := DirAccess.rename_absolute(tmp, save_path)
	if err != OK:
		push_warning("Save failed: rename error %d" % err)
		return false
	game_saved.emit()
	return true


## Returns the validated payload dictionary, or {} when the file is missing/corrupt.
func _read_envelope(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var text := FileAccess.get_file_as_string(path)
	if text.is_empty():
		return {}
	var json := JSON.new()
	if json.parse(text) != OK or typeof(json.data) != TYPE_DICTIONARY:
		return {}
	var env: Dictionary = json.data
	if not (env.has("v") and env.has("sha") and env.has("payload")):
		return {}
	if int(env["v"]) > SAVE_VERSION or typeof(env["payload"]) != TYPE_STRING:
		return {}
	var payload_str: String = env["payload"]
	if payload_str.sha256_text() != String(env["sha"]):
		return {}
	var pj := JSON.new()
	if pj.parse(payload_str) != OK or typeof(pj.data) != TYPE_DICTIONARY:
		return {}
	return pj.data


## Loads the save into the current state. Returns true on success (primary or backup).
func load_game() -> bool:
	last_load_message = ""
	var p := _read_envelope(save_path)
	if p.is_empty():
		p = _read_envelope(save_path + ".bak")
		if not p.is_empty():
			last_load_message = "Your save was damaged; the previous backup was restored."
	if p.is_empty():
		last_load_message = "No usable save found." if not has_save() else "The save file was corrupted and could not be recovered."
		return false
	_apply(p)
	session_active = true
	return true


func delete_save() -> void:
	for suffix in ["", ".bak", ".tmp"]:
		if FileAccess.file_exists(save_path + suffix):
			DirAccess.remove_absolute(save_path + suffix)


# ----- defensive value readers -----
func _to_f(v: Variant, d: float) -> float:
	if typeof(v) == TYPE_INT or typeof(v) == TYPE_FLOAT:
		var x := float(v)
		return d if (is_nan(x) or is_inf(x)) else x
	return d


func _f(p: Dictionary, k: String, dflt: float, lo: float, hi: float) -> float:
	return clampf(_to_f(p.get(k, dflt), dflt), lo, hi)


func _b(p: Dictionary, k: String, dflt: bool) -> bool:
	var v: Variant = p.get(k, dflt)
	return bool(v) if typeof(v) == TYPE_BOOL else dflt


func _counts(p: Dictionary, k: String, allowed: Dictionary) -> Dictionary:
	var out := {}
	var v: Variant = p.get(k, {})
	if typeof(v) != TYPE_DICTIONARY:
		return out
	for key in v:
		if allowed.has(String(key)) and (typeof(v[key]) == TYPE_FLOAT or typeof(v[key]) == TYPE_INT):
			var n := int(v[key])
			if n > 0:
				out[String(key)] = mini(n, 9999)
	return out


func _ids(p: Dictionary, k: String, allowed: Dictionary) -> Array:
	var out: Array = []
	var v: Variant = p.get(k, [])
	if typeof(v) != TYPE_ARRAY:
		return out
	for e in v:
		if typeof(e) == TYPE_STRING and (allowed.is_empty() or allowed.has(e)) and not out.has(e):
			out.append(e)
	return out


func _apply(p: Dictionary) -> void:
	level = int(_f(p, "level", 1, 1, 99))
	xp = int(_f(p, "xp", 0, 0, 999999))
	coins = int(_f(p, "coins", 0, 0, 999999))
	kills = int(_f(p, "kills", 0, 0, 999999))
	inventory = _counts(p, "inventory", Items.ITEMS)
	var eq: Variant = p.get("equipment", {})
	equipment = {"weapon": "worn_scimitar", "armor": "travelers_wraps"}
	if typeof(eq) == TYPE_DICTIONARY:
		for slot in ["weapon", "armor"]:
			var id: String = String(eq.get(slot, ""))
			if Items.ITEMS.has(id) and String(Items.ITEMS[id].type) == slot and count(id) > 0:
				equipment[slot] = id
	var up: Dictionary = {"vitality": 0, "blade": 0, "endurance": 0}
	var upv: Variant = p.get("upgrades", {})
	if typeof(upv) == TYPE_DICTIONARY:
		for k in up:
			up[k] = int(clampf(_to_f(upv.get(k, 0), 0.0), 0.0, float(Items.UPGRADES[k].max)))
	upgrades = up
	camp_level = int(_f(p, "camp_level", 1, 1, Items.CAMP_MAX_LEVEL))
	stash = _counts(p, "stash", Items.ITEMS)
	quest_stage = int(_f(p, "quest_stage", 0, 0, 5))
	fragments_found = int(_f(p, "fragments_found", 0, 0, Items.FRAGMENTS_REQUIRED))
	gate_open = _b(p, "gate_open", false)
	boss_defeated = _b(p, "boss_defeated", false)
	quest_completed = _b(p, "quest_completed", false)
	var dials: Array = [0, 0, 0]
	var dv: Variant = p.get("puzzle_dials", [])
	if typeof(dv) == TYPE_ARRAY and dv.size() == 3:
		for i in 3:
			dials[i] = int(clampf(_to_f(dv[i], 0.0), 0.0, 3.0))
	puzzle_dials = dials
	puzzle_solved = _b(p, "puzzle_solved", false)
	clue_found = _b(p, "clue_found", false)
	discovered_ids = _ids(p, "discovered", Items.LOCATIONS)
	if not discovered_ids.has("camp"):
		discovered_ids.append("camp")
	var allowed_open := {"frag_alcove": 1, "frag_temple": 1, "frag_wraith": 1}
	allowed_open.merge(Items.CHESTS)
	opened_ids = _ids(p, "opened", allowed_open)
	var cp := String(p.get("checkpoint", "camp"))
	checkpoint_id = cp if Items.LOCATIONS.has(cp) and Items.LOCATIONS[cp].waystone else "camp"
	has_position = false
	var pv: Variant = p.get("pos", [])
	if typeof(pv) == TYPE_ARRAY and pv.size() == 3 and _b(p, "has_pos", false):
		var comps: Array = []
		for c in pv:
			comps.append(_to_f(c, INF))
		var ok := not comps.has(INF)
		if ok and absf(comps[0]) < Items.WORLD_HALF and absf(comps[2]) < Items.WORLD_HALF and comps[1] > -60.0 and comps[1] < 80.0:
			player_pos = Vector3(comps[0], comps[1], comps[2])
			has_position = true
	player_yaw = _f(p, "yaw", 0.0, -100.0, 100.0)
	play_time = _f(p, "play_time", 0.0, 0.0, 1.0e9)
	intro_seen = _b(p, "intro_seen", false)
	# Keep invariants between related fields.
	if gate_open:
		quest_stage = maxi(quest_stage, 3)
	if boss_defeated:
		quest_stage = maxi(quest_stage, 4)
	if quest_completed:
		quest_stage = 5
	hp = _f(p, "hp", max_hp(), 1.0, max_hp())
	stamina = max_stamina()
	inventory_changed.emit()
	stats_changed.emit()
	quest_changed.emit()


# =============================================================== settings
func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) != OK:
		return
	music_volume = clampf(float(cf.get_value("audio", "music", music_volume)), 0.0, 1.0)
	sfx_volume = clampf(float(cf.get_value("audio", "sfx", sfx_volume)), 0.0, 1.0)
	quality = clampi(int(cf.get_value("graphics", "quality", quality)), 0, 2)
	look_sensitivity = clampf(float(cf.get_value("controls", "look", look_sensitivity)), 0.4, 2.5)
	invert_y = bool(cf.get_value("controls", "invert_y", invert_y))
	haptics = bool(cf.get_value("controls", "haptics", haptics))


func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("audio", "music", music_volume)
	cf.set_value("audio", "sfx", sfx_volume)
	cf.set_value("graphics", "quality", quality)
	cf.set_value("controls", "look", look_sensitivity)
	cf.set_value("controls", "invert_y", invert_y)
	cf.set_value("controls", "haptics", haptics)
	cf.save(SETTINGS_PATH)


func apply_settings() -> void:
	settings_changed.emit()
	save_settings()
