extends Node
## Audio: SFX pool, crossfading music, ambience loop, independent Music/SFX bus volumes.
## Sounds are loaded lazily and optionally - if a file is missing the game simply stays silent.

const DIR := "res://assets/audio/"
const LOOPS := ["music_menu", "music_world", "music_boss", "ambience", "fire"]
const POOL_SIZE := 14

var _cache: Dictionary = {}
var _pool: Array[AudioStreamPlayer] = []
var _music: Array[AudioStreamPlayer] = []
var _music_idx := 0
var _ambience: AudioStreamPlayer
var current_music := ""
var _music_tween: Tween
var _muted_by_focus := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ensure_bus("Music")
	_ensure_bus("SFX")
	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_pool.append(p)
	for i in 2:
		var m := AudioStreamPlayer.new()
		m.bus = "Music"
		m.volume_db = -60.0
		add_child(m)
		_music.append(m)
	_ambience = AudioStreamPlayer.new()
	_ambience.bus = "SFX"
	_ambience.volume_db = -9.0
	add_child(_ambience)
	GameState.settings_changed.connect(apply_volumes)
	apply_volumes()


func _ensure_bus(bus_name: String) -> void:
	if AudioServer.get_bus_index(bus_name) != -1:
		return
	AudioServer.add_bus()
	var idx := AudioServer.bus_count - 1
	AudioServer.set_bus_name(idx, bus_name)
	AudioServer.set_bus_send(idx, "Master")


func apply_volumes() -> void:
	_set_bus("Music", GameState.music_volume)
	_set_bus("SFX", GameState.sfx_volume)


func _set_bus(bus_name: String, v: float) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx == -1:
		return
	AudioServer.set_bus_mute(idx, v <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(v, 0.0001)))


func get_stream(sound: String) -> AudioStream:
	if _cache.has(sound):
		return _cache[sound]
	var path := DIR + sound + ".wav"
	var s: AudioStream = null
	if ResourceLoader.exists(path):
		var loaded := load(path)
		if loaded is AudioStreamWAV:
			var w: AudioStreamWAV = loaded.duplicate()
			if LOOPS.has(sound):
				w.loop_mode = AudioStreamWAV.LOOP_FORWARD
				w.loop_begin = 0
				w.loop_end = int(w.get_length() * w.mix_rate)
			s = w
		elif loaded is AudioStream:
			s = loaded
	_cache[sound] = s
	return s


func play(sound: String, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	var s := get_stream(sound)
	if s == null:
		return
	var p: AudioStreamPlayer = null
	for c in _pool:
		if not c.playing:
			p = c
			break
	if p == null:
		p = _pool[0]
	p.stream = s
	p.volume_db = volume_db
	p.pitch_scale = pitch
	p.play()


## Plays a sound attenuated by distance to the active 3D camera (cheap positional audio).
func play_at(sound: String, pos: Vector3, max_dist: float = 40.0, volume_db: float = 0.0) -> void:
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		play(sound, volume_db)
		return
	var d := cam.global_position.distance_to(pos)
	if d >= max_dist:
		return
	var f := 1.0 - d / max_dist
	play(sound, volume_db + linear_to_db(f * f), randf_range(0.95, 1.05))


func play_music(track: String, fade: float = 1.6) -> void:
	if track == current_music:
		return
	current_music = track
	var s := get_stream(track)
	var incoming := _music[_music_idx]
	var outgoing := _music[1 - _music_idx]
	_music_idx = 1 - _music_idx
	if _music_tween:
		_music_tween.kill()
	_music_tween = create_tween().set_parallel(true)
	if outgoing.playing:
		_music_tween.tween_property(outgoing, "volume_db", -60.0, fade)
	if s != null:
		incoming.stream = s
		incoming.volume_db = -60.0
		incoming.play()
		_music_tween.tween_property(incoming, "volume_db", 0.0, fade)
	_music_tween.chain().tween_callback(func(): if outgoing.volume_db <= -59.0: outgoing.stop())


func stop_music(fade: float = 1.0) -> void:
	current_music = ""
	if _music_tween:
		_music_tween.kill()
	_music_tween = create_tween().set_parallel(true)
	for m in _music:
		if m.playing:
			_music_tween.tween_property(m, "volume_db", -60.0, fade)
	_music_tween.chain().tween_callback(func(): for m in _music: m.stop())


func set_ambience(on: bool) -> void:
	if on:
		var s := get_stream("ambience")
		if s != null and not _ambience.playing:
			_ambience.stream = s
			_ambience.play()
	else:
		_ambience.stop()


## A looping positional sound (e.g. the campfire). Caller adds the returned node to the tree.
func make_loop_3d(sound: String, max_dist: float = 24.0, volume_db: float = -4.0) -> AudioStreamPlayer3D:
	var p := AudioStreamPlayer3D.new()
	p.bus = "SFX"
	p.max_distance = max_dist
	p.unit_size = 6.0
	p.volume_db = volume_db
	p.autoplay = false
	var s := get_stream(sound)
	if s != null:
		p.stream = s
		p.autoplay = true
	return p


func _notification(what: int) -> void:
	match what:
		NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_APPLICATION_FOCUS_OUT:
			_muted_by_focus = true
			AudioServer.set_bus_mute(0, true)
		NOTIFICATION_APPLICATION_RESUMED, NOTIFICATION_APPLICATION_FOCUS_IN:
			if _muted_by_focus:
				_muted_by_focus = false
				AudioServer.set_bus_mute(0, false)
