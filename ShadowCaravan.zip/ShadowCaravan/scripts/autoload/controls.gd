extends Node
## Aggregates touch-screen and keyboard input into one stream for the player, camera and HUD.
## Touch widgets (joystick, buttons, look pad) write into this node; the keyboard works too,
## which makes the game testable on a desktop.

signal attack_pressed
signal dodge_pressed
signal jump_pressed
signal interact_pressed
signal back_pressed      # Android back button / Escape: close a menu or open the pause menu
signal map_pressed
signal inventory_pressed
signal journal_pressed

var touch_move := Vector2.ZERO  # virtual joystick output, y negative = forward
var sprint_held := false
var look_delta := Vector2.ZERO
var enabled := true             # false while a menu/dialogue is open or during cutscenes


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().set_quit_on_go_back(false)  # Android back button opens the pause menu instead of quitting


func get_move() -> Vector2:
	if not enabled:
		return Vector2.ZERO
	if touch_move.length() > 0.05:
		return touch_move
	return Input.get_vector("move_left", "move_right", "move_up", "move_down")


func is_sprint() -> bool:
	return enabled and (sprint_held or Input.is_action_pressed("sprint"))


func consume_look() -> Vector2:
	var v := look_delta
	look_delta = Vector2.ZERO
	return v


func reset_touch() -> void:
	touch_move = Vector2.ZERO
	sprint_held = false
	look_delta = Vector2.ZERO


func vibrate(ms: int) -> void:
	if GameState.haptics and OS.has_feature("mobile"):
		Input.vibrate_handheld(ms)


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		back_pressed.emit()
		return
	if not enabled:
		return
	if event.is_action_pressed("attack"):
		attack_pressed.emit()
	elif event.is_action_pressed("dodge"):
		dodge_pressed.emit()
	elif event.is_action_pressed("jump"):
		jump_pressed.emit()
	elif event.is_action_pressed("interact"):
		interact_pressed.emit()
	elif event.is_action_pressed("open_map"):
		map_pressed.emit()
	elif event.is_action_pressed("open_inventory"):
		inventory_pressed.emit()
	elif event.is_action_pressed("open_journal"):
		journal_pressed.emit()
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		look_delta += (event as InputEventMouseMotion).relative


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		back_pressed.emit()
