extends Node3D
## A collectible dropped by enemies / chests: coins, materials, potions. Pops out, bobs and glows,
## is magnetised to the player when close, and grants its contents on contact.

const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")
const Items := preload("res://scripts/data/items.gd")

var item_id := ""     # "" => coins
var amount := 1
var _t := 0.0
var _vel := Vector3.ZERO
var _grounded := false
var _life := 0.0
var _mesh: MeshInstance3D
var _base_y := 0.0
var _collected := false
var _ground_y := 0.0


static func spawn(parent: Node, pos: Vector3, p_item: String, p_amount: int, ground_y: float) -> Node3D:
	var p: Node3D = (load("res://scripts/world/pickup.gd") as GDScript).new()
	p.item_id = p_item
	p.amount = p_amount
	p._ground_y = ground_y
	parent.add_child(p)
	p.global_position = pos
	return p


func _ready() -> void:
	_vel = Vector3(randf_range(-2.2, 2.2), randf_range(4.0, 6.0), randf_range(-2.2, 2.2))
	_mesh = MeshInstance3D.new()
	var col := Color(0.95, 0.78, 0.25)
	if item_id == "":
		var cm := CylinderMesh.new()
		cm.top_radius = 0.2
		cm.bottom_radius = 0.2
		cm.height = 0.05
		cm.radial_segments = 12
		cm.rings = 1
		_mesh.mesh = cm
		_mesh.rotation_degrees.x = 90
	else:
		var info := Items.item(item_id)
		match String(info.icon):
			"potion":
				col = Color(0.85, 0.2, 0.25)
			"shell":
				col = Color(0.2, 0.6, 0.62)
			"dust":
				col = Color(0.65, 0.82, 1.0)
			"glass":
				col = Color(0.95, 0.75, 0.35)
			"fragment":
				col = Color(0.25, 0.9, 0.85)
		var sm := SphereMesh.new()
		sm.radius = 0.2
		sm.height = 0.5
		sm.radial_segments = 5
		sm.rings = 3
		_mesh.mesh = sm
	_mesh.material_override = Mats.glow(col, 2.2)
	_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_mesh)
	Fx.emitter(self, Vector3(0, 0.1, 0), Color(col.r, col.g, col.b, 0.7), 4, 1.0, 0.06, Vector3(0, 0.4, 0), 40.0, Vector3(0.12, 0, 0.12))


func _physics_process(delta: float) -> void:
	_t += delta
	_life += delta
	if not _grounded:
		_vel.y -= 16.0 * delta
		global_position += _vel * delta
		if global_position.y <= _ground_y + 0.4 and _vel.y < 0.0:
			global_position.y = _ground_y + 0.4
			_grounded = true
			_base_y = global_position.y
	else:
		_mesh.position.y = sin(_t * 3.0) * 0.08
	_mesh.rotate_y(delta * 2.5)
	var pl: Node3D = GameState.player_ref
	if not is_instance_valid(pl) or _collected or _life < 0.45:
		return
	var d := global_position.distance_to(pl.global_position + Vector3(0, 0.8, 0))
	if d < 4.0 and _grounded:
		global_position = global_position.move_toward(pl.global_position + Vector3(0, 0.8, 0), delta * (3.0 + (4.0 - d) * 4.0))
	if d < 1.3:
		_collect()


func _collect() -> void:
	_collected = true
	if item_id == "":
		GameState.add_coins(amount)
		AudioMgr.play("coin", -2.0, randf_range(0.95, 1.12))
	else:
		GameState.add_item(item_id, amount)
		AudioMgr.play("pickup", -2.0)
	Fx.burst(get_parent(), global_position, Color(1, 0.9, 0.5, 0.9), 8, 2.5, 0.4, 0.09, 2.0)
	queue_free()
