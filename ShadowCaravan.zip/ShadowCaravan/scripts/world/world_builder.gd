extends RefCounted
## Assembles the whole level under a Node3D: sky + lighting, terrain mesh and trimesh collider, invisible
## world-edge walls, scattered rocks / trees, the distant city skyline, and (via world_areas.gd) all landmarks.
## `build()` returns the refs dictionary of world_areas plus "env", "sun", "fill".

const Mats := preload("res://scripts/world/mats.gd")
const Props := preload("res://scripts/world/props.gd")
const Terrain := preload("res://scripts/world/terrain.gd")
const Areas := preload("res://scripts/world/world_areas.gd")

const SUN_DIR := Vector3(-0.8, 0.2, -0.4)    # direction TOWARDS the sun (low in the north-west)
const MOON_DIR := Vector3(0.5, 0.62, -0.45)  # direction towards the moon (high in the north-east)

const SKY_SHADER := """shader_type sky;
uniform vec3 sun_dir = vec3(-0.8, 0.2, -0.4);
uniform vec3 moon_dir = vec3(0.5, 0.62, -0.45);
uniform vec3 top_col : source_color = vec3(0.012, 0.02, 0.07);
uniform vec3 mid_col : source_color = vec3(0.12, 0.07, 0.2);
uniform vec3 hor_col : source_color = vec3(0.9, 0.38, 0.15);

float hash21(vec2 p) {
	return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void sky() {
	vec3 d = normalize(EYEDIR);
	float h = clamp(d.y, -0.3, 1.0);
	vec3 col = mix(hor_col, mid_col, smoothstep(0.0, 0.22, h));
	col = mix(col, top_col, smoothstep(0.15, 0.75, h));
	vec3 sd = normalize(sun_dir);
	float s = max(dot(d, sd), 0.0);
	col += vec3(1.0, 0.45, 0.15) * pow(s, 5.0) * 0.6;
	col += vec3(1.0, 0.75, 0.4) * pow(s, 70.0) * 0.9;
	col = mix(col, vec3(1.0, 0.86, 0.55), smoothstep(0.9972, 0.9984, s));
	vec3 md = normalize(moon_dir);
	float m = dot(d, md);
	col += vec3(0.35, 0.45, 0.8) * pow(max(m, 0.0), 80.0) * 0.4;
	col = mix(col, vec3(0.9, 0.93, 1.0), smoothstep(0.9988, 0.9992, m));
	// stars
	vec2 uv = vec2(atan(d.x, d.z), asin(clamp(d.y, -1.0, 1.0)));
	vec2 g = uv * vec2(80.0, 80.0);
	vec2 cell = floor(g);
	float r = hash21(cell);
	vec2 f = fract(g) - 0.5;
	float star = step(0.975, r) * smoothstep(0.32, 0.0, length(f));
	star *= 0.6 + 0.4 * sin(TIME * (1.0 + r * 3.0) + r * 40.0);
	col += vec3(0.85, 0.9, 1.0) * star * smoothstep(0.18, 0.55, h) * (1.0 - s * 0.8);
	if (d.y < 0.0) {
		col = mix(hor_col * 0.55, vec3(0.1, 0.07, 0.07), clamp(-d.y * 5.0, 0.0, 1.0));
	}
	COLOR = col;
}
"""


static func build(world: Node3D) -> Dictionary:
	var lights := _environment(world)
	_terrain(world)
	_boundary(world)
	_scatter(world)
	_skyline(world)
	var refs := Areas.build_all(world)
	refs.merge(lights)
	for l in world.find_children("*", "OmniLight3D", true, false):
		l.add_to_group("opt_lights")
	return refs


static func _environment(world: Node3D) -> Dictionary:
	var shader := Shader.new()
	shader.code = SKY_SHADER
	var sm := ShaderMaterial.new()
	sm.shader = shader
	sm.set_shader_parameter("sun_dir", SUN_DIR.normalized())
	sm.set_shader_parameter("moon_dir", MOON_DIR.normalized())
	var sky := Sky.new()
	sky.sky_material = sm
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.46, 0.4, 0.58)
	env.ambient_light_energy = 0.95
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.05
	env.fog_enabled = true
	env.fog_light_color = Color(0.62, 0.38, 0.36)
	env.fog_density = 0.0036
	env.glow_enabled = false
	var we := WorldEnvironment.new()
	we.environment = env
	world.add_child(we)
	var sun := DirectionalLight3D.new()
	sun.light_color = Color(1.0, 0.64, 0.38)
	sun.light_energy = 1.55
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = 80.0
	sun.shadow_bias = 0.06
	sun.shadow_normal_bias = 1.2
	world.add_child(sun)
	sun.basis = Basis.looking_at(-SUN_DIR.normalized(), Vector3.UP)
	var fill := DirectionalLight3D.new()
	fill.light_color = Color(0.45, 0.55, 0.95)
	fill.light_energy = 0.42
	fill.shadow_enabled = false
	world.add_child(fill)
	fill.basis = Basis.looking_at(-MOON_DIR.normalized(), Vector3.UP)
	return {"env": env, "sun": sun, "fill": fill}


static func _terrain(world: Node3D) -> void:
	var mesh := Terrain.build_mesh()
	var mi := MeshInstance3D.new()
	mi.name = "Terrain"
	mi.mesh = mesh
	mi.material_override = Mats.vertex_colored(1.0)
	world.add_child(mi)
	var body := StaticBody3D.new()
	body.name = "TerrainBody"
	body.collision_layer = 1
	body.collision_mask = 0
	var cs := CollisionShape3D.new()
	var shape := ConcavePolygonShape3D.new()
	shape.backface_collision = true
	shape.set_faces(Terrain.collision_faces())
	cs.shape = shape
	body.add_child(cs)
	world.add_child(body)


static func _boundary(world: Node3D) -> void:
	# invisible walls just outside the playable square so nothing can ever leave the level
	for def in [[Vector3(0, 20, -100.5), Vector3(214, 60, 3)], [Vector3(0, 20, 100.5), Vector3(214, 60, 3)],
			[Vector3(-100.5, 20, 0), Vector3(3, 60, 214)], [Vector3(100.5, 20, 0), Vector3(3, 60, 214)]]:
		var b := StaticBody3D.new()
		b.collision_layer = 1
		b.collision_mask = 0
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = def[1]
		cs.shape = bs
		b.add_child(cs)
		world.add_child(b)
		b.position = def[0]


static func _scatter(world: Node3D) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20260
	var rock_cols := [Color(0.42, 0.34, 0.29), Color(0.36, 0.3, 0.27), Color(0.5, 0.4, 0.31)]
	var placed := 0
	var tries := 0
	while placed < 70 and tries < 600:
		tries += 1
		var x := rng.randf_range(-92.0, 92.0)
		var z := rng.randf_range(-92.0, 92.0)
		if absf(z + 56.0) < 9.0 or not Terrain.is_flat_free(x, z, 1.5):
			continue
		var big := rng.randf() < 0.3
		var sc := rng.randf_range(1.6, 2.8) if big else rng.randf_range(0.7, 1.4)
		Props.rock(world, Vector3(x, Terrain.height_at(x, z) - 0.15, z), Vector3(sc, sc * rng.randf_range(0.6, 1.1), sc * rng.randf_range(0.8, 1.2)),
			rng.randi_range(0, 9), big, rock_cols[rng.randi_range(0, 2)])
		placed += 1
	placed = 0
	tries = 0
	while placed < 14 and tries < 300:
		tries += 1
		var tx := rng.randf_range(-90.0, 90.0)
		var tz := rng.randf_range(-90.0, 90.0)
		if absf(tz + 56.0) < 9.0 or not Terrain.is_flat_free(tx, tz, 3.0):
			continue
		Props.dead_tree(world, Vector3(tx, Terrain.height_at(tx, tz), tz), rng.randf_range(3.0, 5.2), rng.randi_range(0, 9))
		placed += 1
	for i in 6:
		var bx := rng.randf_range(-85.0, 85.0)
		var bz := rng.randf_range(-85.0, 85.0)
		if absf(bz + 56.0) < 9.0 or not Terrain.is_flat_free(bx, bz, 2.0):
			continue
		Props.bones(world, Vector3(bx, Terrain.height_at(bx, bz), bz), i)


static func _skyline(world: Node3D) -> void:
	var city := Props.city_silhouette(world, Vector3(0, -6, -340), 320.0, 11)
	city.scale = Vector3(1.6, 1.9, 1.0)
	var city2 := Props.city_silhouette(world, Vector3(360, -6, -60), 200.0, 29)
	city2.rotation_degrees.y = 90.0
	city2.scale = Vector3(1.4, 1.5, 1.0)
