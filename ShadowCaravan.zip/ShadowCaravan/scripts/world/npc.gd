extends Node3D
## A procedural NPC: breathes, and turns to face the player when they come close.

const Rig := preload("res://scripts/world/character_rig.gd")

var rig: Node3D
var look_range := 7.0
var base_yaw := 0.0


func setup(pal: Dictionary) -> void:
	rig = Rig.new()
	add_child(rig)
	rig.build(pal)


func _process(delta: float) -> void:
	if rig == null:
		return
	rig.state = "idle"
	rig.animate(delta)
	var p: Node3D = GameState.player_ref
	if p != null and is_instance_valid(p):
		var d := p.global_position - global_position
		d.y = 0.0
		if d.length() < look_range and d.length() > 0.1:
			rotation.y = lerp_angle(rotation.y, atan2(-d.x, -d.z), minf(1.0, 3.0 * delta))
			return
	rotation.y = lerp_angle(rotation.y, base_yaw, minf(1.0, 1.5 * delta))
