extends Node3D
## Third-person follow camera: touch / mouse look, smoothed follow, wall & terrain collision
## avoidance (ray from the pivot to the desired camera spot), and screen shake.

var target: Node3D
var yaw := 0.0
var pitch := -0.3
var distance := 5.8
var cam: Camera3D
var _shake := 0.0
var _pivot := Vector3.ZERO
var _cur_dist := 5.8
var _snap := true

const PITCH_MIN := -1.15
const PITCH_MAX := 0.5


func _ready() -> void:
	cam = Camera3D.new()
	cam.top_level = true
	cam.fov = 68.0
	cam.near = 0.12
	cam.far = 700.0
	add_child(cam)
	cam.make_current()


func snap_to_target() -> void:
	_snap = true


func add_shake(amount: float) -> void:
	_shake = minf(1.0, _shake + amount)


func bearing_deg() -> float:
	var f := -cam.global_transform.basis.z
	return fposmod(rad_to_deg(atan2(f.x, -f.z)), 360.0)


func _process(delta: float) -> void:
	if not is_instance_valid(target):
		return
	var look := Controls.consume_look()
	if look != Vector2.ZERO:
		var sens := GameState.look_sensitivity
		yaw -= look.x * 0.0042 * sens
		var inv := -1.0 if GameState.invert_y else 1.0
		pitch = clampf(pitch - look.y * 0.0036 * sens * inv, PITCH_MIN, PITCH_MAX)
	var want := target.global_position + Vector3(0, 1.5, 0)
	if _snap:
		_pivot = want
		_snap = false
	else:
		_pivot = _pivot.lerp(want, 1.0 - exp(-14.0 * delta))
	var basis := Basis(Vector3.UP, yaw) * Basis(Vector3.RIGHT, pitch)
	var dir := basis * Vector3(0, 0, 1)
	var desired := _pivot + dir * distance
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(_pivot, desired, 1)
	var hit := space.intersect_ray(q)
	var dist := distance
	if not hit.is_empty():
		dist = maxf(1.0, _pivot.distance_to(hit.position) - 0.35)
	# pull in fast, ease back out slowly
	if dist < _cur_dist:
		_cur_dist = dist
	else:
		_cur_dist = lerpf(_cur_dist, dist, 1.0 - exp(-4.0 * delta))
	var pos := _pivot + dir * _cur_dist
	if _shake > 0.001:
		pos += Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * _shake * 0.25
		_shake = maxf(0.0, _shake - delta * 2.4)
	cam.global_position = pos
	cam.look_at(_pivot + Vector3(0, 0.2, 0), Vector3.UP)
