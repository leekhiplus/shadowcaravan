extends Node3D
## Procedural humanoid built from primitives, animated by rotating joint pivots.
## States: idle, walk, run, attack, roll, hurt, jump, dead. (No external model/animation assets are
## needed, so the project stays fully original and tiny.)

const Mats := preload("res://scripts/world/mats.gd")

var state := "idle"
var phase := 0.0          # 0..1 progress for attack / roll
var swing_variant := 0
var speed01 := 0.0        # 0..1 of sprint speed, drives the walk cycle

var pivot: Node3D         # rolls rotate this around the body centre
var visual: Node3D
var hips: Node3D
var torso: Node3D
var head: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var cape: Node3D
var scarf_tail: Node3D
var sword: Node3D
var _parts: Array[MeshInstance3D] = []
var _walk := 0.0
var _t := 0.0
var _flash := 0.0
var _flash_mat: StandardMaterial3D
var _dead_t := 0.0


func _part(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	m.mesh = mesh
	m.material_override = mat
	parent.add_child(m)
	m.position = pos
	m.rotation_degrees = rot_deg
	_parts.append(m)
	return m


func _box(parent: Node3D, size: Vector3, mat: Material, pos: Vector3, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var b := BoxMesh.new()
	b.size = size
	return _part(parent, b, mat, pos, rot_deg)


func _ball(parent: Node3D, r: float, mat: Material, pos: Vector3, sc: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 10
	s.rings = 6
	var m := _part(parent, s, mat, pos)
	m.scale = sc
	return m


func _joint(parent: Node3D, pos: Vector3) -> Node3D:
	var j := Node3D.new()
	parent.add_child(j)
	j.position = pos
	return j


## pal keys: cloak, trim, skin, scarf, eye, sword (bool), staff (bool), cape
func build(pal: Dictionary) -> void:
	pivot = _joint(self, Vector3(0, 0.9, 0))
	visual = _joint(pivot, Vector3(0, -0.9, 0))
	var cloak := Mats.cloth(pal.get("cloak", Color("1b2a50")))
	var cape_m := Mats.cloth(pal.get("cape", Color("0f1830")))
	var trim := Mats.solid(pal.get("trim", Color("c9a24b")), 0.4, 0.6)
	var skin := Mats.solid(pal.get("skin", Color("a8744d")), 0.9)
	var scarf := Mats.cloth(pal.get("scarf", Color("d9c39a")))
	var boot := Mats.solid(Color(0.14, 0.1, 0.08), 1.0)
	var eye := Mats.glow(pal.get("eye", Color("3fd0c9")), 3.0)

	hips = _joint(visual, Vector3(0, 0.95, 0))
	leg_l = _joint(hips, Vector3(-0.12, 0.0, 0))
	leg_r = _joint(hips, Vector3(0.12, 0.0, 0))
	for lg in [leg_l, leg_r]:
		_box(lg, Vector3(0.17, 0.8, 0.2), Mats.cloth(Color("14182a")), Vector3(0, -0.42, 0))
		_box(lg, Vector3(0.2, 0.13, 0.31), boot, Vector3(0, -0.86, -0.04))
	torso = _joint(hips, Vector3.ZERO)
	_box(torso, Vector3(0.46, 0.56, 0.27), cloak, Vector3(0, 0.3, 0))
	_box(torso, Vector3(0.5, 0.07, 0.3), trim, Vector3(0, 0.03, 0))
	_box(torso, Vector3(0.08, 0.5, 0.29), trim, Vector3(0.1, 0.3, 0))
	_ball(torso, 0.1, trim, Vector3(-0.28, 0.56, 0))
	_ball(torso, 0.1, trim, Vector3(0.28, 0.56, 0))
	head = _joint(torso, Vector3(0, 0.7, 0))
	_ball(head, 0.15, skin, Vector3(0, 0.1, 0))
	_ball(head, 0.185, scarf, Vector3(0, 0.15, 0.015), Vector3(1.0, 0.82, 1.0))
	_box(head, Vector3(0.27, 0.11, 0.03), Mats.solid(Color(0.05, 0.05, 0.08), 1.0), Vector3(0, 0.09, -0.15))
	_box(head, Vector3(0.045, 0.03, 0.02), eye, Vector3(-0.05, 0.1, -0.168))
	_box(head, Vector3(0.045, 0.03, 0.02), eye, Vector3(0.05, 0.1, -0.168))
	scarf_tail = _joint(head, Vector3(0.1, 0.12, 0.17))
	_box(scarf_tail, Vector3(0.1, 0.45, 0.04), scarf, Vector3(0, -0.2, 0.03))
	arm_l = _joint(torso, Vector3(-0.3, 0.55, 0))
	arm_r = _joint(torso, Vector3(0.3, 0.55, 0))
	for a in [arm_l, arm_r]:
		_box(a, Vector3(0.12, 0.5, 0.12), cloak, Vector3(0, -0.25, 0))
		_ball(a, 0.07, skin, Vector3(0, -0.54, 0))
	cape = _joint(torso, Vector3(0, 0.56, 0.15))
	_box(cape, Vector3(0.46, 0.88, 0.03), cape_m, Vector3(0, -0.43, 0.02))
	_box(cape, Vector3(0.48, 0.05, 0.04), trim, Vector3(0, -0.88, 0.02))
	if pal.get("sword", true):
		sword = _joint(arm_r, Vector3(0, -0.54, 0))
		sword.rotation_degrees = Vector3(-70, 0, 0)
		var steel := Mats.solid(Color(0.82, 0.87, 0.92), 0.28, 0.9)
		_box(sword, Vector3(0.04, 0.17, 0.04), Mats.solid(Color(0.2, 0.12, 0.08), 1.0), Vector3(0, 0.0, 0))
		_box(sword, Vector3(0.22, 0.035, 0.06), trim, Vector3(0, 0.1, 0))
		_box(sword, Vector3(0.05, 0.5, 0.012), steel, Vector3(0, 0.38, 0))
		_box(sword, Vector3(0.055, 0.36, 0.012), steel, Vector3(0, 0.78, -0.045), Vector3(-12, 0, 0))
		_box(sword, Vector3(0.012, 0.6, 0.016), Mats.glow(Color("3fd0c9"), 1.2), Vector3(0, 0.45, 0.0))
	if pal.get("staff", false):
		var st := CylinderMesh.new()
		st.top_radius = 0.025
		st.bottom_radius = 0.035
		st.height = 1.9
		_part(arm_r, st, Mats.wood(), Vector3(0, -0.55, -0.05))
		_ball(arm_r, 0.08, Mats.glow(Color("3fd0c9"), 2.5), Vector3(0, 0.4, -0.05))
	_flash_mat = Mats.unshaded(Color(1.0, 0.25, 0.2, 0.55), true)


func flash(duration: float = 0.14) -> void:
	_flash = duration
	for p in _parts:
		p.material_overlay = _flash_mat


func _pose(n: Node3D, rx: float, ry: float, rz: float, k: float) -> void:
	n.rotation = Vector3(lerp_angle(n.rotation.x, rx, k), lerp_angle(n.rotation.y, ry, k), lerp_angle(n.rotation.z, rz, k))


func reset_pose() -> void:
	pivot.rotation = Vector3.ZERO
	pivot.position = Vector3(0, 0.9, 0)
	state = "idle"
	_dead_t = 0.0


func animate(delta: float) -> void:
	_t += delta
	if _flash > 0.0:
		_flash -= delta
		if _flash <= 0.0:
			for p in _parts:
				p.material_overlay = null
	var k := minf(1.0, delta * 16.0)
	var bob := 0.0
	var run := clampf((speed01 - 0.4) / 0.6, 0.0, 1.0)
	match state:
		"walk", "run":
			_walk += delta * lerpf(7.0, 12.5, run) * (0.6 + 0.6 * speed01)
			var amp := lerpf(0.55, 0.95, run)
			var s := sin(_walk)
			_pose(leg_l, s * amp, 0, 0, k)
			_pose(leg_r, -s * amp, 0, 0, k)
			_pose(arm_l, -s * amp * 0.8, 0, 0.05, k)
			_pose(arm_r, s * amp * 0.5 + 0.35, 0, -0.05, k)
			_pose(torso, -0.05 - run * 0.2, sin(_walk) * 0.08, 0, k)
			_pose(head, run * 0.1, 0, 0, k)
			_pose(cape, 0.15 + run * 0.7, 0, sin(_walk * 0.5) * 0.05, k)
			bob = absf(sin(_walk)) * 0.05 * (1.0 + run)
			pivot.position.y = lerpf(pivot.position.y, 0.9, k)
			pivot.rotation.x = lerp_angle(pivot.rotation.x, 0.0, k)
		"attack":
			_animate_attack()
			pivot.rotation.x = lerp_angle(pivot.rotation.x, 0.0, k)
		"roll":
			var e := phase * phase * (3.0 - 2.0 * phase)
			pivot.rotation.x = -TAU * e
			pivot.position.y = 0.9 - 0.32 * sin(PI * phase)
			_pose(leg_l, -1.4, 0, 0, 0.5)
			_pose(leg_r, -1.4, 0, 0, 0.5)
			_pose(arm_l, -1.2, 0, 0.3, 0.5)
			_pose(arm_r, -1.2, 0, -0.3, 0.5)
			_pose(torso, -0.3, 0, 0, 0.5)
		"hurt":
			_pose(torso, 0.35, 0, 0, k)
			_pose(head, 0.3, 0, 0, k)
			_pose(arm_l, 0.6, 0, 0.5, k)
			_pose(arm_r, 0.6, 0, -0.5, k)
			_pose(leg_l, 0.2, 0, 0, k)
			_pose(leg_r, -0.3, 0, 0, k)
			pivot.rotation.x = lerp_angle(pivot.rotation.x, 0.0, k)
		"jump":
			_pose(leg_l, -0.7, 0, 0, k)
			_pose(leg_r, 0.3, 0, 0, k)
			_pose(arm_l, -2.3, 0, 0.5, k)
			_pose(arm_r, -2.0, 0, -0.5, k)
			_pose(torso, -0.1, 0, 0, k)
			_pose(cape, 0.9, 0, 0, k)
		"dead":
			_dead_t += delta
			var u := clampf(_dead_t / 0.6, 0.0, 1.0)
			pivot.rotation.x = lerp_angle(pivot.rotation.x, 1.52, 1.0 - exp(-delta * 7.0))
			pivot.position.y = lerpf(0.9, 0.2, u)
			_pose(arm_l, 0.4, 0, 1.0, k)
			_pose(arm_r, 0.3, 0, -1.0, k)
		_:  # idle
			var br := sin(_t * 2.0)
			_pose(leg_l, 0, 0, 0, k)
			_pose(leg_r, 0, 0, 0, k)
			_pose(arm_l, br * 0.03, 0, 0.06, k)
			_pose(arm_r, 0.45 + br * 0.03, 0, -0.06, k)
			_pose(torso, br * 0.012, 0, 0, k)
			_pose(head, sin(_t * 0.7) * 0.04, sin(_t * 0.5) * 0.15, 0, k * 0.5)
			_pose(cape, 0.06 + br * 0.02, 0, 0, k)
			pivot.position.y = lerpf(pivot.position.y, 0.9, k)
			pivot.rotation.x = lerp_angle(pivot.rotation.x, 0.0, k)
	hips.position.y = 0.95 + bob
	scarf_tail.rotation.x = 0.3 + sin(_t * 5.0 + _walk) * 0.12 + speed01 * 0.5
	scarf_tail.rotation.z = sin(_t * 3.0) * 0.1


func _animate_attack() -> void:
	var p := phase
	var ax := 0.0
	var az := 0.0
	var ty := 0.0
	var sgn := -1.0 if swing_variant == 0 else 1.0
	if p < 0.3:
		var u := p / 0.3
		u = u * u
		if swing_variant == 0:
			ax = lerpf(0.45, 2.9, u)
			az = lerpf(-0.06, -0.2, u)
		else:
			ax = lerpf(0.45, 1.5, u)
			az = lerpf(-0.06, -1.6, u)
		ty = lerpf(0.0, 0.5 * sgn, u)
	elif p < 0.6:
		var u := (p - 0.3) / 0.3
		u = 1.0 - pow(1.0 - u, 3.0)
		if swing_variant == 0:
			ax = lerpf(2.9, -0.15, u)
			az = lerpf(-0.2, -0.05, u)
		else:
			ax = lerpf(1.5, 1.3, u)
			az = lerpf(-1.6, 1.3, u)
		ty = lerpf(0.5 * sgn, -0.6 * sgn, u)
	else:
		var u := (p - 0.6) / 0.4
		u = u * u * (3.0 - 2.0 * u)
		if swing_variant == 0:
			ax = lerpf(-0.15, 0.45, u)
		else:
			ax = lerpf(1.3, 0.45, u)
			az = lerpf(1.3, -0.06, u)
		ty = lerpf(-0.6 * sgn, 0.0, u)
	arm_r.rotation = Vector3(ax, 0.0, az)
	torso.rotation = Vector3(-0.1, ty, 0.0)
	arm_l.rotation = Vector3(-0.5, 0.0, 0.3)
	_pose(leg_l, 0.4, 0, 0, 0.4)
	_pose(leg_r, -0.5, 0, 0, 0.4)
