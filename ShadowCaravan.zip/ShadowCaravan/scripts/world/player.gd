extends CharacterBody3D
## Third-person player: walk / jog / sprint, jump, scimitar attack with a real hit window, dodge roll
## with a short invulnerability window, stamina, damage / death, and interaction detection.

const Rig := preload("res://scripts/world/character_rig.gd")
const Fx := preload("res://scripts/world/fx.gd")
const Mats := preload("res://scripts/world/mats.gd")

signal damaged(amount: float)
signal died
signal prompt_changed(text: String)
signal interact_requested(node: Node3D)
signal swing_hit(enemy: Node3D, amount: float)

# --- tuning (all times in seconds)
const WALK_SPEED := 3.4
const JOG_SPEED := 5.4
const SPRINT_SPEED := 8.2
const JUMP_VEL := 8.6
const GRAVITY := 24.0
const ROLL_TIME := 0.55
const ROLL_SPEED := 10.0
const IFRAME_START := 0.05      # dodge invulnerability window: 0.05s .. 0.38s into the roll
const IFRAME_END := 0.38
const ATTACK_TIME := 0.56
const HIT_START := 0.30         # damage window as a fraction of the swing
const HIT_END := 0.62
const ATTACK_RANGE := 2.7
const ATTACK_ARC_COS := 0.1     # about +-84 degrees in front
const ATTACK_COOLDOWN := 0.1
const DODGE_COOLDOWN := 0.25
const ATTACK_STAMINA := 7.0
const ROLL_STAMINA := 22.0
const JUMP_STAMINA := 9.0
const SPRINT_DRAIN := 17.0
const STAMINA_REGEN := 26.0
const REGEN_DELAY := 0.85

var cam: Node3D                 # camera rig (provides yaw)
var rig: Node3D
var state := "move"             # move | attack | roll | hurt | dead
var attack_t := -1.0
var roll_t := -1.0
var hurt_t := 0.0
var attack_cd := 0.0
var dodge_cd := 0.0
var interact_target: Node3D = null
var frozen := false             # set during cutscenes / teleports

var _hit_set: Dictionary = {}
var _roll_dir := Vector3.ZERO
var _variant := 0
var _queued_attack := false
var _stam_delay := 0.0
var _exhausted := false
var _jump_buffer := 0.0
var _coyote := 0.0
var _step_t := 0.0
var _scan_t := 0.0
var _safe_pos := Vector3.ZERO
var _safe_t := 0.0
var _slash: MeshInstance3D
var _slash_t := 0.0
var _last_prompt := ""
var _knock := Vector3.ZERO
var _dust_t := 0.0


func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1 | 4
	floor_max_angle = deg_to_rad(52.0)
	floor_snap_length = 0.55
	floor_stop_on_slope = true
	max_slides = 5
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.34
	cap.height = 1.76
	cs.shape = cap
	cs.position = Vector3(0, 0.88, 0)
	add_child(cs)
	rig = Rig.new()
	add_child(rig)
	rig.build({"cloak": Color("1b2a50"), "trim": Color("c9a24b"), "scarf": Color("d9c39a"), "sword": true})
	_slash = MeshInstance3D.new()
	_slash.mesh = Fx.slash_arc()
	_slash.material_override = Fx.slash_material()
	_slash.visible = false
	_slash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_slash)
	_slash.position = Vector3(0, 1.1, 0)
	GameState.player_ref = self
	Controls.attack_pressed.connect(_try_attack)
	Controls.dodge_pressed.connect(_try_roll)
	Controls.jump_pressed.connect(func(): _jump_buffer = 0.14)
	Controls.interact_pressed.connect(_try_interact)
	_safe_pos = global_position


func _exit_tree() -> void:
	for sig in [Controls.attack_pressed, Controls.dodge_pressed, Controls.jump_pressed, Controls.interact_pressed]:
		for c in sig.get_connections():
			if c.callable.get_object() == self:
				sig.disconnect(c.callable)
	if GameState.player_ref == self:
		GameState.player_ref = null


# ----------------------------------------------------------------- queries
func is_invulnerable() -> bool:
	return state == "roll" and roll_t >= IFRAME_START and roll_t <= IFRAME_END


func is_dead() -> bool:
	return state == "dead"


func facing() -> Vector3:
	return Vector3(-sin(rotation.y), 0.0, -cos(rotation.y))


func cooldown_fraction(which: String) -> float:
	if which == "attack":
		return clampf(attack_cd / 0.5, 0.0, 1.0) if state != "attack" else 0.0
	return clampf(dodge_cd / DODGE_COOLDOWN, 0.0, 1.0) if state != "roll" else 0.0


# ----------------------------------------------------------------- actions
func _spend(amount: float) -> bool:
	if GameState.stamina <= 0.5:
		return false
	GameState.stamina = maxf(0.0, GameState.stamina - amount)
	_stam_delay = REGEN_DELAY
	return true


func _try_attack() -> void:
	if frozen or state == "dead" or state == "roll" or state == "hurt":
		return
	if state == "attack":
		if attack_t > ATTACK_TIME * 0.45:
			_queued_attack = true
		return
	if attack_cd > 0.0:
		return
	if not _spend(ATTACK_STAMINA):
		GameState.toast.emit("Too exhausted to swing!", "warn")
		return
	state = "attack"
	attack_t = 0.0
	_hit_set.clear()
	_variant = 1 - _variant
	rig.swing_variant = _variant
	_queued_attack = false
	_auto_aim()
	AudioMgr.play("sword_swing", -2.0, randf_range(0.92, 1.1))
	Controls.vibrate(15)


func _auto_aim() -> void:
	var best: Node3D = null
	var best_d := 5.0
	for e in get_tree().get_nodes_in_group("enemies"):
		if e.has_method("is_dead") and e.is_dead():
			continue
		var d := global_position.distance_to(e.global_position)
		if d < best_d:
			var to: Vector3 = (e.global_position - global_position)
			to.y = 0.0
			if to.length() > 0.01 and facing().dot(to.normalized()) > -0.2:
				best_d = d
				best = e
	if best != null:
		var to2: Vector3 = best.global_position - global_position
		rotation.y = atan2(-to2.x, -to2.z)


func _try_roll() -> void:
	if frozen or state == "dead" or state == "roll" or dodge_cd > 0.0:
		return
	if state == "hurt" and hurt_t > 0.12:
		return
	if not _spend(ROLL_STAMINA):
		GameState.toast.emit("Not enough stamina to dodge!", "warn")
		return
	var mv := Controls.get_move()
	var dir := Vector3.ZERO
	if mv.length() > 0.2 and cam != null:
		dir = Vector3(mv.x, 0, mv.y).rotated(Vector3.UP, cam.yaw).normalized()
	else:
		dir = facing()
	_roll_dir = dir
	rotation.y = atan2(-dir.x, -dir.z)
	state = "roll"
	roll_t = 0.0
	attack_t = -1.0
	_slash.visible = false
	AudioMgr.play("roll", -2.0)
	Fx.burst(get_parent(), global_position + Vector3(0, 0.2, 0), Color(0.9, 0.75, 0.5, 0.4), 8, 2.0, 0.5, 0.25, 1.0)


func _try_interact() -> void:
	if frozen or state == "dead" or state == "roll":
		return
	if is_instance_valid(interact_target) and interact_target.has_method("is_available") and interact_target.is_available():
		interact_requested.emit(interact_target)
		interact_target.activate()


func take_damage(amount: float, from_pos: Vector3, _source: Object = null) -> void:
	if state == "dead":
		return
	if is_invulnerable():
		Fx.floating_text(get_parent(), global_position + Vector3(0, 2.2, 0), "Dodged!", Color("8fe6df"), 48)
		return
	var dmg := maxf(1.0, amount - GameState.armor_defense())
	GameState.hp = maxf(0.0, GameState.hp - dmg)
	GameState.stats_changed.emit()
	damaged.emit(dmg)
	rig.flash(0.16)
	AudioMgr.play("hit_player", -1.0)
	Controls.vibrate(60)
	Fx.floating_text(get_parent(), global_position + Vector3(0, 2.3, 0), str(int(dmg)), Color("ff6b63"), 60)
	Fx.burst(get_parent(), global_position + Vector3(0, 1.2, 0), Color(1.0, 0.3, 0.25, 0.9), 10, 3.5, 0.4, 0.12)
	if cam != null and cam.has_method("add_shake"):
		cam.add_shake(0.35)
	if GameState.hp <= 0.0:
		_die()
		return
	var away := global_position - from_pos
	away.y = 0.0
	_knock = away.normalized() * 6.0 if away.length() > 0.01 else Vector3.ZERO
	if state != "roll":
		state = "hurt"
		hurt_t = 0.28
		attack_t = -1.0
		_slash.visible = false


func _die() -> void:
	state = "dead"
	attack_t = -1.0
	roll_t = -1.0
	_slash.visible = false
	rig.state = "dead"
	AudioMgr.play("player_death")
	Controls.vibrate(250)
	died.emit()


func respawn(pos: Vector3, yaw: float = 0.0) -> void:
	global_position = pos
	velocity = Vector3.ZERO
	rotation.y = yaw
	state = "move"
	attack_t = -1.0
	roll_t = -1.0
	hurt_t = 0.0
	attack_cd = 0.0
	dodge_cd = 0.0
	frozen = false
	rig.reset_pose()
	_safe_pos = pos
	GameState.stamina = GameState.max_stamina()


func teleport(pos: Vector3) -> void:
	global_position = pos
	velocity = Vector3.ZERO
	_safe_pos = pos


# ----------------------------------------------------------------- physics
func _physics_process(delta: float) -> void:
	attack_cd = maxf(0.0, attack_cd - delta)
	dodge_cd = maxf(0.0, dodge_cd - delta)
	_jump_buffer = maxf(0.0, _jump_buffer - delta)
	if state == "dead":
		velocity.x = move_toward(velocity.x, 0.0, 30.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 30.0 * delta)
		velocity.y -= GRAVITY * delta
		move_and_slide()
		rig.animate(delta)
		return
	if frozen:
		velocity.x = 0.0
		velocity.z = 0.0
		velocity.y -= GRAVITY * delta
		move_and_slide()
		rig.state = "idle"
		rig.animate(delta)
		return

	var on_floor := is_on_floor()
	if on_floor:
		_coyote = 0.12
	else:
		_coyote = maxf(0.0, _coyote - delta)

	var mv := Controls.get_move()
	var mag := minf(mv.length(), 1.0)
	var yaw: float = cam.yaw if cam != null else 0.0
	var desired := Vector3(mv.x, 0, mv.y).rotated(Vector3.UP, yaw)
	if desired.length() > 0.001:
		desired = desired.normalized()

	# --- speed from stick magnitude: walk (gentle push) -> jog (full push) -> sprint (button)
	var speed := 0.0
	var sprinting := false
	if mag > 0.05:
		if mag < 0.6:
			speed = WALK_SPEED * (mag / 0.6)
		else:
			speed = lerpf(WALK_SPEED, JOG_SPEED, (mag - 0.6) / 0.4)
		if Controls.is_sprint() and not _exhausted and GameState.stamina > 0.0 and state == "move":
			speed = SPRINT_SPEED
			sprinting = true

	var target_vel := desired * speed
	match state:
		"move":
			var accel := 46.0 if on_floor else 14.0
			velocity.x = move_toward(velocity.x, target_vel.x, accel * delta)
			velocity.z = move_toward(velocity.z, target_vel.z, accel * delta)
			if desired.length() > 0.01 and speed > 0.2:
				var want := atan2(-desired.x, -desired.z)
				rotation.y = lerp_angle(rotation.y, want, minf(1.0, 14.0 * delta))
			if _jump_buffer > 0.0 and _coyote > 0.0 and GameState.stamina >= 1.0:
				_spend(JUMP_STAMINA)
				velocity.y = JUMP_VEL
				_jump_buffer = 0.0
				_coyote = 0.0
				AudioMgr.play("jump", -4.0)
		"attack":
			attack_t += delta
			var u := attack_t / ATTACK_TIME
			var lunge := 0.0
			if u > 0.25 and u < 0.55:
				lunge = 2.6
			var f := facing()
			velocity.x = move_toward(velocity.x, f.x * lunge + target_vel.x * 0.25, 40.0 * delta)
			velocity.z = move_toward(velocity.z, f.z * lunge + target_vel.z * 0.25, 40.0 * delta)
			rig.phase = u
			if u >= HIT_START and u <= HIT_END:
				_apply_hits()
				_show_slash(true, u)
			else:
				_show_slash(false, u)
			if u >= 1.0:
				state = "move"
				attack_t = -1.0
				attack_cd = ATTACK_COOLDOWN
				_slash.visible = false
				if _queued_attack:
					_queued_attack = false
					_try_attack()
		"roll":
			roll_t += delta
			var e := 1.0 - pow(roll_t / ROLL_TIME, 2.0)
			velocity.x = _roll_dir.x * ROLL_SPEED * maxf(e, 0.25)
			velocity.z = _roll_dir.z * ROLL_SPEED * maxf(e, 0.25)
			rig.phase = clampf(roll_t / ROLL_TIME, 0.0, 1.0)
			_dust_t -= delta
			if _dust_t <= 0.0 and on_floor:
				_dust_t = 0.12
				Fx.burst(get_parent(), global_position + Vector3(0, 0.1, 0), Color(0.9, 0.75, 0.5, 0.35), 3, 1.0, 0.45, 0.22, 0.5)
			if roll_t >= ROLL_TIME:
				state = "move"
				roll_t = -1.0
				dodge_cd = DODGE_COOLDOWN
		"hurt":
			hurt_t -= delta
			velocity.x = move_toward(velocity.x, _knock.x, 40.0 * delta)
			velocity.z = move_toward(velocity.z, _knock.z, 40.0 * delta)
			_knock = _knock.move_toward(Vector3.ZERO, 22.0 * delta)
			if hurt_t <= 0.0:
				state = "move"

	if not on_floor:
		velocity.y -= GRAVITY * delta
	elif velocity.y < 0.0:
		velocity.y = -1.0
	move_and_slide()

	# --- stamina
	if sprinting and mag > 0.1:
		GameState.stamina = maxf(0.0, GameState.stamina - SPRINT_DRAIN * delta)
		_stam_delay = REGEN_DELAY
		if GameState.stamina <= 0.0:
			_exhausted = true
	elif _stam_delay > 0.0:
		_stam_delay -= delta
	else:
		GameState.stamina = minf(GameState.max_stamina(), GameState.stamina + STAMINA_REGEN * delta)
		if _exhausted and GameState.stamina > 22.0:
			_exhausted = false

	# --- animation state
	var hspeed := Vector2(velocity.x, velocity.z).length()
	rig.speed01 = clampf(hspeed / SPRINT_SPEED, 0.0, 1.0)
	match state:
		"attack":
			rig.state = "attack"
		"roll":
			rig.state = "roll"
		"hurt":
			rig.state = "hurt"
		_:
			if not on_floor and velocity.y > -0.5 and not is_on_floor():
				rig.state = "jump"
			elif hspeed > 5.8:
				rig.state = "run"
			elif hspeed > 0.6:
				rig.state = "walk"
			else:
				rig.state = "idle"
	rig.animate(delta)

	# --- footsteps and dust
	if on_floor and hspeed > 1.5 and state == "move":
		_step_t -= delta * (hspeed / 4.0)
		if _step_t <= 0.0:
			_step_t = 0.45
			AudioMgr.play("step1" if randf() > 0.5 else "step2", -12.0, randf_range(0.9, 1.1))
			if hspeed > 6.0:
				Fx.burst(get_parent(), global_position + Vector3(0, 0.1, 0), Color(0.9, 0.75, 0.5, 0.3), 3, 1.0, 0.5, 0.2, 0.5)

	# --- safety nets
	_safe_t -= delta
	if on_floor and _safe_t <= 0.0 and state == "move":
		_safe_t = 1.0
		_safe_pos = global_position
	if global_position.y < -25.0:
		teleport(_safe_pos + Vector3(0, 1.0, 0))
		GameState.toast.emit("You slipped back onto solid ground.", "info")
	global_position.x = clampf(global_position.x, -97.0, 97.0)
	global_position.z = clampf(global_position.z, -97.0, 97.0)

	# --- interaction scan (10 Hz)
	_scan_t -= delta
	if _scan_t <= 0.0:
		_scan_t = 0.1
		_scan_interactables()


func _scan_interactables() -> void:
	var best: Node3D = null
	var best_d := 1.0e9
	for n in get_tree().get_nodes_in_group("interactables"):
		if not n.has_method("is_available") or not n.is_available():
			continue
		var d3: Vector3 = n.global_position - global_position
		if absf(d3.y) > 4.0:
			d3.y = 0.0
		var d := Vector2(d3.x, d3.z).length()
		if d < float(n.radius) and d < best_d:
			best_d = d
			best = n
	interact_target = best
	var text := ""
	if best != null and state != "dead":
		text = String(best.prompt)
	if text != _last_prompt:
		_last_prompt = text
		prompt_changed.emit(text)


# ----------------------------------------------------------------- combat
func _show_slash(on: bool, u: float) -> void:
	if on:
		if not _slash.visible:
			_slash.visible = true
			_slash.rotation = Vector3(0, 0, deg_to_rad(-25.0) if _variant == 0 else deg_to_rad(20.0))
			_slash.scale = Vector3(-1 if _variant == 1 else 1, 1, 1)
		var s := 0.85 + 0.25 * ((u - HIT_START) / (HIT_END - HIT_START))
		_slash.scale = Vector3(s * (-1.0 if _variant == 1 else 1.0), 1.0, s)
	else:
		_slash.visible = false


func damage_roll() -> float:
	var base := GameState.weapon_damage() * (1.0 + 0.04 * float(GameState.level - 1))
	base *= randf_range(0.9, 1.1)
	return base


func _apply_hits() -> void:
	var f := facing()
	var chest := global_position + Vector3(0, 1.1, 0)
	var space := get_world_3d().direct_space_state
	for e in get_tree().get_nodes_in_group("enemies"):
		if _hit_set.has(e.get_instance_id()):
			continue
		if e.has_method("is_dead") and e.is_dead():
			continue
		var to: Vector3 = e.global_position - global_position
		var dy := absf(to.y)
		to.y = 0.0
		var dist := to.length()
		var reach: float = ATTACK_RANGE + float(e.hit_radius if "hit_radius" in e else 0.5)
		if dist > reach or dy > 2.6:
			continue
		if dist > 0.4 and f.dot(to.normalized()) < ATTACK_ARC_COS:
			continue
		# cannot hit through walls
		var target_pt: Vector3 = e.global_position + Vector3(0, 0.9, 0)
		var q := PhysicsRayQueryParameters3D.create(chest, target_pt, 1)
		if not space.intersect_ray(q).is_empty():
			continue
		_hit_set[e.get_instance_id()] = true
		var dmg := damage_roll()
		var crit := randf() < 0.08
		if crit:
			dmg *= 1.6
		e.take_damage(dmg, global_position, self, crit)
		AudioMgr.play("hit_enemy", -1.0, randf_range(0.92, 1.08))
		Controls.vibrate(25)
		if cam != null and cam.has_method("add_shake"):
			cam.add_shake(0.14)
		swing_hit.emit(e, dmg)
