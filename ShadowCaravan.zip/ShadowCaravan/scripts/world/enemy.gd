extends CharacterBody3D
## Enemy with an explicit finite-state machine.
##
## Kinds
##   "scarab" - fast melee skirmisher. Circles you, telegraphs with a crouch + red eyes, then lunges.
##   "wraith" - ranged caster. Keeps its distance, backs away when you close in, telegraphs with a
##              growing orb and fires a slow projectile you can dodge, block with walls, or roll through.
##
## States: IDLE -> CHASE -> (HOLD / KITE) -> WINDUP -> ATTACK -> RECOVER -> CHASE ... plus HURT, RETREAT
## (leash: walks home and heals when the player is too far away) and DEAD.
## Attacks only land if the target is inside the attack's real reach AND an unobstructed ray exists
## between the two (no hits through walls, no unlimited range).
## The Hollow Warden boss (boss.gd) extends this class and overrides the AI.

const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")
const Items := preload("res://scripts/data/items.gd")
const Rig := preload("res://scripts/world/character_rig.gd")
const Props := preload("res://scripts/world/props.gd")
const Terrain := preload("res://scripts/world/terrain.gd")
const Projectile := preload("res://scripts/world/projectile.gd")
const Pickup := preload("res://scripts/world/pickup.gd")

signal died(enemy: Node3D)

enum S { IDLE, CHASE, HOLD, KITE, WINDUP, ATTACK, RECOVER, HURT, RETREAT, DEAD, DORMANT, WAKE }
const STATE_NAMES := ["idle", "chase", "hold", "kite", "windup", "attack", "recover", "hurt", "retreat", "dead", "dormant", "wake"]

# --- configuration (set by _configure per kind)
var kind := "scarab"
var display_name := "Dune Scarab"
var max_hp := 36.0
var hp := 36.0
var damage := 9.0
var move_speed := 4.4
var accel := 30.0
var turn_rate := 9.0
var aggro_range := 14.0
var leash_range := 34.0
var attack_trigger := 2.6      # start an attack when closer than this
var windup_time := 0.5
var attack_time := 0.32
var recover_time := 0.8
var attack_cooldown := 1.1
var hit_radius := 0.6          # used by the player's sword for reach
var eye_height := 0.5
var bar_height := 1.4
var col_radius := 0.5
var col_height := 1.0
var xp_reward := 12
var ranged := false
var show_world_bar := true

var home := Vector3.ZERO
var state: int = S.IDLE
var state_t := 0.0

var _t := 0.0
var _cd := 1.0
var _stagger_immune := 0.0
var _los_t := 0.0
var _los := false
var _dist := 999.0
var _dir_to := Vector3(0, 0, -1)
var _wander_t := 0.0
var _wander_dir := Vector3.ZERO
var _lock_dir := Vector3.ZERO
var _knock := Vector3.ZERO
var _did_hit := false
var _fired := false
var _strafe := 1.0
var _strafe_t := 0.0
var _kite_t := 0.0
var _bar_t := 0.0
var _stuck_t := 0.0
var _body: Node3D
var _rig: Node3D
var _orb: MeshInstance3D
var _legs: Array = []
var _meshes: Array[MeshInstance3D] = []
var _flash_t := 0.0
var _flash_mat: StandardMaterial3D
var _eye_mat: StandardMaterial3D
var _bar: MeshInstance3D
var _bar_mat: ShaderMaterial

static var _bar_shader: Shader


## Spawn helper. `parent` must be an identity-transform Node3D (the world root).
static func spawn(parent: Node, p_kind: String, pos: Vector3) -> Node3D:
	var e: Node3D = (load("res://scripts/world/enemy.gd") as GDScript).new()
	e.kind = p_kind
	e.home = pos
	e.position = pos
	parent.add_child(e)
	return e


static func _get_bar_shader() -> Shader:
	if _bar_shader == null:
		_bar_shader = Shader.new()
		_bar_shader.code = """shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, shadows_disabled;
uniform float fill = 1.0;
uniform vec4 col : source_color = vec4(0.82, 0.18, 0.16, 1.0);
void vertex() {
	MODELVIEW_MATRIX = VIEW_MATRIX * mat4(INV_VIEW_MATRIX[0], INV_VIEW_MATRIX[1], INV_VIEW_MATRIX[2], MODEL_MATRIX[3]);
}
void fragment() {
	vec2 uv = UV;
	float edge = step(uv.x, 0.025) + step(0.975, uv.x) + step(uv.y, 0.16) + step(0.84, uv.y);
	vec3 c = uv.x <= fill ? col.rgb : vec3(0.1, 0.06, 0.06);
	if (edge > 0.0) {
		c = vec3(0.03, 0.02, 0.02);
	}
	ALBEDO = c;
	ALPHA = 0.96;
}
"""
	return _bar_shader


# ================================================================= setup
func _configure() -> void:
	match kind:
		"wraith":
			display_name = "Dune Wraith"
			max_hp = 48.0
			damage = 12.0
			move_speed = 3.6
			aggro_range = 19.0
			leash_range = 30.0
			attack_trigger = 16.0
			windup_time = 0.8
			attack_time = 0.3
			recover_time = 0.6
			attack_cooldown = 1.9
			hit_radius = 0.55
			eye_height = 1.5
			bar_height = 3.0
			col_radius = 0.4
			col_height = 1.8
			xp_reward = int(Items.XP_VALUES.wraith)
			ranged = true
			turn_rate = 7.0
		_:
			kind = "scarab"
			display_name = "Dune Scarab"
			max_hp = 36.0
			damage = 9.0
			move_speed = 4.6
			aggro_range = 14.0
			leash_range = 34.0
			attack_trigger = 2.7
			windup_time = 0.5
			attack_time = 0.32
			recover_time = 0.85
			attack_cooldown = 1.2
			hit_radius = 0.6
			eye_height = 0.5
			bar_height = 1.5
			col_radius = 0.5
			col_height = 1.0
			xp_reward = int(Items.XP_VALUES.scarab)


func _ready() -> void:
	_configure()
	hp = max_hp
	collision_layer = 4
	collision_mask = 1 | 2 | 4
	floor_snap_length = 0.5
	floor_max_angle = deg_to_rad(55.0)
	add_to_group("enemies")
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = col_radius
	cap.height = maxf(col_height, col_radius * 2.0 + 0.01)
	cs.shape = cap
	cs.position = Vector3(0, cap.height * 0.5, 0)
	add_child(cs)
	_flash_mat = Mats.unshaded(Color(1.0, 0.25, 0.2, 0.55), true)
	_build_visual()
	_collect_meshes(self)
	if show_world_bar:
		_build_bar()
	_cd = randf_range(0.4, 1.4)
	_strafe = 1.0 if randf() > 0.5 else -1.0
	_after_ready()


func _after_ready() -> void:
	pass


func _build_visual() -> void:
	if kind == "wraith":
		_build_wraith()
	else:
		_build_scarab()


func _collect_meshes(n: Node) -> void:
	for c in n.get_children():
		if c is MeshInstance3D and c != _bar:
			_meshes.append(c)
		_collect_meshes(c)


func _build_scarab() -> void:
	_body = Node3D.new()
	add_child(_body)
	var shell := Mats.solid(Color(0.09, 0.3, 0.33), 0.35, 0.55)
	var dark := Mats.solid(Color(0.05, 0.09, 0.11), 0.6, 0.2)
	var gold := Mats.solid(Color(0.82, 0.62, 0.2), 0.4, 0.7)
	_eye_mat = Mats.glow(Color(1.0, 0.3, 0.2), 2.0).duplicate()
	Props.sphere(_body, 0.5, Vector3(0, 0.42, 0.18), shell, Vector3(0.9, 0.62, 1.25))
	Props.sphere(_body, 0.34, Vector3(0, 0.46, -0.3), dark, Vector3(1.0, 0.7, 1.0))
	Props.sphere(_body, 0.23, Vector3(0, 0.38, -0.62), dark)
	Props.box(_body, Vector3(0.07, 0.04, 1.0), Vector3(0, 0.735, 0.18), gold)
	for sx: float in [-1.0, 1.0]:
		var eye := Props.sphere(_body, 0.055, Vector3(0.1 * sx, 0.45, -0.8), _eye_mat, Vector3.ONE, 6, 4)
		eye.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		Props.box(_body, Vector3(0.05, 0.05, 0.3), Vector3(0.12 * sx, 0.3, -0.86), dark, Vector3(0, 28.0 * sx, 0))
		Props.box(_body, Vector3(0.025, 0.025, 0.4), Vector3(0.07 * sx, 0.62, -0.78), dark, Vector3(-30, 14.0 * sx, 0))
	var zs := [-0.32, 0.08, 0.5]
	for side: float in [-1.0, 1.0]:
		for i in 3:
			var j := Node3D.new()
			_body.add_child(j)
			j.position = Vector3(0.36 * side, 0.34, zs[i])
			var base_z: float = 0.95 * side
			j.rotation.z = base_z
			Props.box(j, Vector3(0.06, 0.6, 0.06), Vector3(0, -0.28, 0), dark)
			_legs.append({"j": j, "phase": float(i) * 2.1 + (PI if side > 0.0 else 0.0), "base_z": base_z})


func _build_wraith() -> void:
	_body = Node3D.new()
	add_child(_body)
	_rig = Rig.new()
	_body.add_child(_rig)
	_rig.build({"cloak": Color("2a1c44"), "cape": Color("160d2a"), "trim": Color("7be0d8"),
		"skin": Color("3a2e55"), "scarf": Color("4a3a6e"), "eye": Color("ff4fa0"), "sword": false, "staff": true})
	_rig.leg_l.visible = false
	_rig.leg_r.visible = false
	Props.cyl(_rig.hips, 0.3, 0.03, 1.05, Vector3(0, -0.42, 0), Mats.cloth(Color("22163a")), false, Vector3.ZERO, 10)
	_body.position.y = 0.55
	_orb = MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.2
	sm.height = 0.4
	sm.radial_segments = 8
	sm.rings = 4
	_orb.mesh = sm
	_orb.material_override = Mats.glow(Color(0.8, 0.3, 1.0), 4.0)
	_orb.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_rig.arm_r.add_child(_orb)
	_orb.position = Vector3(0, 0.62, -0.05)
	_orb.visible = false
	Fx.emitter(_body, Vector3(0, 0.9, 0), Color(0.6, 0.35, 1.0, 0.5), 6, 1.2, 0.12, Vector3(0, 0.5, 0), 30.0, Vector3(0.3, 0.2, 0.3))


func _build_bar() -> void:
	_bar = MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(1.1, 0.13)
	_bar.mesh = q
	_bar_mat = ShaderMaterial.new()
	_bar_mat.shader = _get_bar_shader()
	_bar.material_override = _bar_mat
	_bar.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_bar)
	_bar.position = Vector3(0, bar_height, 0)
	_bar.visible = false


# ================================================================= queries
func is_dead() -> bool:
	return state == S.DEAD


func state_name() -> String:
	return STATE_NAMES[state]


func _player() -> Node3D:
	var p: Node3D = GameState.player_ref
	if p == null or not is_instance_valid(p):
		return null
	if p.has_method("is_dead") and p.is_dead():
		return null
	return p


func _check_los(p: Node3D) -> bool:
	var space := get_world_3d().direct_space_state
	var from := global_position + Vector3(0, eye_height, 0)
	var to := p.global_position + Vector3(0, 1.1, 0)
	var q := PhysicsRayQueryParameters3D.create(from, to, 1)
	return space.intersect_ray(q).is_empty()


func _enter(s: int) -> void:
	state = s
	state_t = 0.0
	_did_hit = false
	_fired = false
	_on_enter(s)


func _on_enter(s: int) -> void:
	if s == S.HURT:
		_stagger_immune = 0.8
	if s == S.KITE:
		_kite_t = randf_range(0.7, 1.2)
	if s == S.ATTACK and kind == "scarab":
		AudioMgr.play_at("roll", global_position, 25.0, -6.0)
	if s != S.WINDUP and s != S.ATTACK and _orb != null:
		_orb.visible = false


# ================================================================= main loop
func _physics_process(delta: float) -> void:
	_t += delta
	state_t += delta
	_cd = maxf(0.0, _cd - delta)
	_stagger_immune = maxf(0.0, _stagger_immune - delta)
	_los_t -= delta
	if state == S.DEAD:
		_tick_dead(delta)
		return
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= 24.0 * delta
	var p := _player()
	_sense(p)
	_ai(delta, p)
	move_and_slide()
	_post_move(delta)
	_animate(delta)
	_update_bar(delta)


func _sense(p: Node3D) -> void:
	if p == null:
		_dist = 999.0
		_los = false
		return
	var to := p.global_position - global_position
	to.y = 0.0
	_dist = to.length()
	if _dist > 0.001:
		_dir_to = to / _dist
	if _los_t <= 0.0:
		_los_t = 0.15
		_los = _check_los(p) if _dist < 70.0 else false


func _ai(delta: float, p: Node3D) -> void:
	match state:
		S.IDLE:
			_st_idle(delta, p)
		S.CHASE:
			_st_chase(delta, p)
		S.HOLD:
			_st_hold(delta, p)
		S.KITE:
			_st_kite(delta, p)
		S.WINDUP:
			_st_windup(delta, p)
		S.ATTACK:
			_st_attack(delta, p)
		S.RECOVER:
			_st_recover(delta, p)
		S.HURT:
			_st_hurt(delta)
		S.RETREAT:
			_st_retreat(delta)


func _post_move(delta: float) -> void:
	var hs := Vector2(velocity.x, velocity.z).length()
	if state == S.CHASE and hs < 0.4 and _dist > attack_trigger:
		_stuck_t += delta
	else:
		_stuck_t = 0.0
	if _stuck_t > 0.8:
		_stuck_t = 0.0
		_strafe = -_strafe
		_wander_dir = _dir_to.cross(Vector3.UP) * _strafe
	global_position.x = clampf(global_position.x, -97.0, 97.0)
	global_position.z = clampf(global_position.z, -97.0, 97.0)


# ================================================================= movement helpers
func _steer(d: Vector3) -> Vector3:
	var space := get_world_3d().direct_space_state
	var from := global_position + Vector3(0, 0.6, 0)
	var q := PhysicsRayQueryParameters3D.create(from, from + d * 1.8, 1)
	var hit := space.intersect_ray(q)
	if hit.is_empty():
		return d
	var n: Vector3 = hit.normal
	if n.y > 0.65:
		return d
	var nf := Vector3(n.x, 0, n.z)
	if nf.length() < 0.01:
		return d
	var s := d.slide(nf.normalized())
	if s.length() < 0.25:
		s = d.cross(Vector3.UP) * _strafe
	return s.normalized()


func _walk(dir: Vector3, speed: float, delta: float, face_dir: Vector3 = Vector3.ZERO) -> void:
	var d := dir
	d.y = 0.0
	if d.length() > 0.01:
		d = _steer(d.normalized())
	var target := d * speed
	velocity.x = move_toward(velocity.x, target.x, accel * delta)
	velocity.z = move_toward(velocity.z, target.z, accel * delta)
	var f := d
	if face_dir.length() > 0.01:
		f = face_dir
	if f.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(-f.x, -f.z), minf(1.0, turn_rate * delta))


func _stop(delta: float, decel: float = 40.0) -> void:
	velocity.x = move_toward(velocity.x, 0.0, decel * delta)
	velocity.z = move_toward(velocity.z, 0.0, decel * delta)


func _face(dir: Vector3, delta: float, rate: float = 12.0) -> void:
	if dir.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(1.0, rate * delta))


func _within_leash() -> bool:
	return global_position.distance_to(home) < leash_range


func _can_notice(p: Node3D) -> bool:
	if p == null:
		return false
	if _dist < aggro_range and _los:
		return true
	return _dist < aggro_range * 0.3


# ================================================================= states
func _st_idle(delta: float, p: Node3D) -> void:
	_wander_t -= delta
	if _wander_t <= 0.0:
		_wander_t = randf_range(1.8, 4.2)
		if randf() < 0.45:
			_wander_dir = Vector3.ZERO
		else:
			var a := randf() * TAU
			_wander_dir = Vector3(cos(a), 0, sin(a))
	var to_home := home - global_position
	to_home.y = 0.0
	if to_home.length() > 6.0:
		_wander_dir = to_home.normalized()
	_walk(_wander_dir, move_speed * 0.3, delta)
	if _can_notice(p):
		_on_notice()
		_enter(S.CHASE)


func _on_notice() -> void:
	pass


## Wake an idle enemy and send it after the player (used by the boss's summons).
func engage() -> void:
	if state == S.IDLE:
		_enter(S.CHASE)


func _st_chase(delta: float, p: Node3D) -> void:
	if p == null or not _within_leash():
		_enter(S.RETREAT)
		return
	if ranged:
		if _dist < 5.5:
			_enter(S.KITE)
			return
		if _dist <= 12.5 and _los:
			_enter(S.HOLD)
			return
		_walk(_dir_to, move_speed, delta)
		return
	# melee: close in, strafe while waiting for the cooldown
	if _dist <= attack_trigger and _los:
		if _cd <= 0.0:
			_enter(S.WINDUP)
			return
		_strafe_t -= delta
		if _strafe_t <= 0.0:
			_strafe_t = randf_range(0.8, 1.6)
			_strafe = -_strafe
		var side := _dir_to.cross(Vector3.UP) * _strafe
		_walk(side + _dir_to * 0.2, move_speed * 0.55, delta, _dir_to)
		return
	_walk(_dir_to, move_speed, delta)


func _st_hold(delta: float, p: Node3D) -> void:
	if p == null or not _within_leash():
		_enter(S.RETREAT)
		return
	if _dist < 5.5:
		_enter(S.KITE)
		return
	if _dist > 13.5 or not _los:
		_enter(S.CHASE)
		return
	_strafe_t -= delta
	if _strafe_t <= 0.0:
		_strafe_t = randf_range(1.2, 2.6)
		_strafe = -_strafe
	var side := _dir_to.cross(Vector3.UP) * _strafe
	_walk(side, move_speed * 0.5, delta, _dir_to)
	if _cd <= 0.0 and _los and _dist <= attack_trigger:
		_enter(S.WINDUP)


func _st_kite(delta: float, p: Node3D) -> void:
	if p == null or not _within_leash():
		_enter(S.RETREAT)
		return
	_kite_t -= delta
	_walk(-_dir_to, move_speed * 1.25, delta, _dir_to)
	# cornered by a wall: stop running and shoot instead
	var hs := Vector2(velocity.x, velocity.z).length()
	if state_t > 0.35 and hs < 0.8 and _cd <= 0.0 and _los:
		_enter(S.WINDUP)
		return
	if _kite_t <= 0.0:
		_enter(S.HOLD)


func _st_windup(delta: float, p: Node3D) -> void:
	_stop(delta)
	if p != null:
		_face(_dir_to, delta, 10.0 if kind == "scarab" else 8.0)
	if _orb != null:
		_orb.visible = true
		var u := clampf(state_t / windup_time, 0.0, 1.0)
		_orb.scale = Vector3.ONE * lerpf(0.2, 1.4, u)
	if state_t >= windup_time:
		if p == null:
			_enter(S.CHASE)
			return
		_lock_dir = _dir_to
		_enter(S.ATTACK)


func _st_attack(delta: float, p: Node3D) -> void:
	if kind == "wraith":
		_stop(delta)
		if not _fired:
			_fired = true
			_fire_orb(p)
		if state_t >= attack_time:
			_cd = attack_cooldown
			_enter(S.RECOVER)
		return
	# scarab lunge
	var u := state_t / attack_time
	var speed := 9.5 * (1.0 - 0.5 * u)
	velocity.x = _lock_dir.x * speed
	velocity.z = _lock_dir.z * speed
	rotation.y = lerp_angle(rotation.y, atan2(-_lock_dir.x, -_lock_dir.z), minf(1.0, 20.0 * delta))
	if not _did_hit and u < 0.85 and p != null:
		_try_melee_hit(p, 1.45)
	if state_t >= attack_time:
		_cd = attack_cooldown
		_enter(S.RECOVER)


func _try_melee_hit(p: Node3D, reach: float) -> void:
	var to := p.global_position - global_position
	var dy := absf(to.y)
	to.y = 0.0
	if to.length() > reach or dy > 1.7 or not _los:
		return
	_did_hit = true
	if p.has_method("take_damage"):
		p.take_damage(damage, global_position, self)


func _fire_orb(p: Node3D) -> void:
	if p == null:
		return
	if _dist > attack_trigger + 3.0 or not _los:
		Fx.burst(get_parent(), global_position + Vector3(0, 2.0, 0), Color(0.7, 0.3, 1.0, 0.7), 8, 2.0, 0.4, 0.1)
		return  # fizzles: target moved out of range or behind cover
	var origin := global_position + Vector3(0, 1.6, 0)
	if _orb != null:
		origin = _orb.global_position
	var target := p.global_position + Vector3(0, 1.1, 0)
	Projectile.spawn(get_parent(), origin, target - origin, 11.0, damage, Color(0.8, 0.3, 1.0), self)


func _st_recover(delta: float, p: Node3D) -> void:
	_stop(delta, 30.0)
	if p != null and kind == "wraith":
		_face(_dir_to, delta, 6.0)
	if state_t >= recover_time:
		if p == null:
			_enter(S.RETREAT)
		else:
			_enter(S.CHASE)


func _st_hurt(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 14.0 * delta)
	velocity.z = move_toward(velocity.z, 0.0, 14.0 * delta)
	if state_t >= 0.3:
		_enter(S.CHASE)


func _st_retreat(delta: float) -> void:
	var to_home := home - global_position
	to_home.y = 0.0
	if to_home.length() < 1.6:
		hp = max_hp
		_enter(S.IDLE)
		return
	_walk(to_home, move_speed * 1.3, delta)


# ================================================================= damage / death
func take_damage(amount: float, from_pos: Vector3, _source: Object = null, crit: bool = false) -> void:
	if state == S.DEAD:
		return
	hp = maxf(0.0, hp - amount)
	_bar_t = 4.0
	_flash_t = 0.14
	_set_flash(true)
	if _rig != null:
		_rig.flash(0.14)
	var col := Color("ffe9a0") if crit else Color("ffffff")
	Fx.floating_text(get_parent(), global_position + Vector3(0, bar_height + 0.3, 0), str(int(round(amount))) + ("!" if crit else ""), col, 70 if crit else 54)
	Fx.burst(get_parent(), global_position + Vector3(0, 0.9, 0), Color(1.0, 0.85, 0.5, 0.9), 8, 3.5, 0.3, 0.1)
	if hp <= 0.0:
		_die(from_pos)
		return
	_on_hurt(from_pos)


func _on_hurt(from_pos: Vector3) -> void:
	if state == S.RETREAT:
		if global_position.distance_to(home) < leash_range * 0.8:
			_enter(S.CHASE)
		return
	if state == S.IDLE:
		_enter(S.CHASE)
	var can_stagger := _stagger_immune <= 0.0 and state != S.ATTACK
	if can_stagger:
		var away := global_position - from_pos
		away.y = 0.0
		if away.length() > 0.01:
			var k := 5.0 if kind == "scarab" else 3.5
			velocity.x = away.normalized().x * k
			velocity.z = away.normalized().z * k
		_enter(S.HURT)


func _die(_from_pos: Vector3) -> void:
	state = S.DEAD
	state_t = 0.0
	remove_from_group("enemies")
	collision_layer = 0
	collision_mask = 1
	if _bar != null:
		_bar.visible = false
	if _orb != null:
		_orb.visible = false
	AudioMgr.play_at("enemy_die", global_position, 40.0, -2.0)
	Fx.burst(get_parent(), global_position + Vector3(0, 0.9, 0), Color(0.9, 0.7, 0.4, 0.9), 16, 4.5, 0.5, 0.14)
	_reward()
	_drop_loot()
	died.emit(self)


func _reward() -> void:
	GameState.kills += 1
	GameState.add_xp(xp_reward)
	Fx.floating_text(get_parent(), global_position + Vector3(0, bar_height + 0.8, 0), "+%d XP" % xp_reward, Color("c9a24b"), 44)


func _drop_loot() -> void:
	var parent := get_parent()
	var pos := global_position + Vector3(0, 0.8, 0)
	var gy := Terrain.height_at(global_position.x, global_position.z)
	if kind == "wraith":
		Pickup.spawn(parent, pos, "", randi_range(6, 14), gy)
		if randf() < 0.65:
			Pickup.spawn(parent, pos, "wraith_dust", 1, gy)
		if randf() < 0.12:
			Pickup.spawn(parent, pos, "sand_glass", 1, gy)
		if randf() < 0.12:
			Pickup.spawn(parent, pos, "healing_draught", 1, gy)
	else:
		Pickup.spawn(parent, pos, "", randi_range(3, 8), gy)
		if randf() < 0.55:
			Pickup.spawn(parent, pos, "scarab_shell", 1, gy)
		if randf() < 0.08:
			Pickup.spawn(parent, pos, "healing_draught", 1, gy)


func _tick_dead(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 20.0 * delta)
	velocity.z = move_toward(velocity.z, 0.0, 20.0 * delta)
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= 24.0 * delta
	move_and_slide()
	if kind == "wraith" and _rig != null:
		_rig.state = "dead"
		_rig.animate(delta)
		var u := clampf((state_t - 0.7) / 0.7, 0.0, 1.0)
		_body.scale = Vector3.ONE * maxf(1.0 - u, 0.01)
	elif _body != null:
		var u := clampf(state_t / 0.35, 0.0, 1.0)
		_body.rotation.z = lerpf(0.0, PI, u)
		_body.position.y = lerpf(0.0, 0.45, u)
		for L in _legs:
			var j: Node3D = L.j
			j.rotation.x = lerpf(j.rotation.x, 0.0, 0.2)
			j.rotation.z = lerpf(j.rotation.z, float(L.base_z) * 0.35, 0.2)
		var s := 1.0 - clampf((state_t - 1.2) / 0.8, 0.0, 1.0)
		_body.scale = Vector3.ONE * maxf(s, 0.01)
	if state_t > 2.1:
		queue_free()


# ================================================================= visuals
func _set_flash(on: bool) -> void:
	for m in _meshes:
		if is_instance_valid(m):
			m.material_overlay = _flash_mat if on else null


func _update_bar(delta: float) -> void:
	if _flash_t > 0.0:
		_flash_t -= delta
		if _flash_t <= 0.0:
			_set_flash(false)
	if _bar == null:
		return
	_bar_t -= delta
	var show := _bar_t > 0.0 and hp < max_hp and state != S.DEAD
	_bar.visible = show
	if show:
		_bar_mat.set_shader_parameter("fill", clampf(hp / max_hp, 0.0, 1.0))


func _phase01() -> float:
	match state:
		S.WINDUP:
			return 0.3 * clampf(state_t / windup_time, 0.0, 1.0)
		S.ATTACK:
			return 0.3 + 0.3 * clampf(state_t / attack_time, 0.0, 1.0)
		S.RECOVER:
			return 0.6 + 0.4 * clampf(state_t / recover_time, 0.0, 1.0)
	return 0.0


func _animate(delta: float) -> void:
	if kind == "wraith":
		_animate_humanoid(delta)
	else:
		_animate_scarab(delta)


func _animate_scarab(delta: float) -> void:
	var hs := Vector2(velocity.x, velocity.z).length()
	var cycle := _t * (6.0 + hs * 2.2)
	var amp := clampf(hs / 3.5, 0.0, 1.0) * 0.55 + 0.04
	for L in _legs:
		var j: Node3D = L.j
		var ph: float = L.phase
		j.rotation.x = sin(cycle + ph) * amp
		j.rotation.z = float(L.base_z) + 0.18 * sin(cycle + ph + 1.6) * amp
	var crouch := 0.0
	var stretch := 0.0
	if state == S.WINDUP:
		crouch = clampf(state_t / windup_time, 0.0, 1.0)
	elif state == S.ATTACK:
		stretch = 1.0
	var target := Vector3(1.0 + crouch * 0.06 - stretch * 0.06, 1.0 - crouch * 0.3 + stretch * 0.05, 1.0 - crouch * 0.05 + stretch * 0.22)
	_body.scale = _body.scale.lerp(target, minf(1.0, delta * 18.0))
	_body.position.y = sin(_t * 10.0) * 0.02 * clampf(hs / 3.0, 0.0, 1.0)
	var rx := -0.35 if state == S.HURT else 0.0
	_body.rotation.x = lerp_angle(_body.rotation.x, rx, minf(1.0, delta * 14.0))
	if _eye_mat != null:
		_eye_mat.emission_energy_multiplier = 2.0 + crouch * 7.0


func _animate_humanoid(delta: float) -> void:
	var hs := Vector2(velocity.x, velocity.z).length()
	match state:
		S.WINDUP, S.ATTACK, S.RECOVER:
			_rig.state = "attack"
			_rig.phase = _phase01()
		S.HURT:
			_rig.state = "hurt"
		S.CHASE, S.KITE, S.RETREAT:
			_rig.state = "walk" if hs > 0.6 else "idle"
		S.HOLD:
			_rig.state = "walk" if hs > 0.6 else "idle"
		_:
			_rig.state = "idle"
	_rig.speed01 = clampf(hs / 8.0, 0.0, 1.0)
	_rig.animate(delta)
	_body.position.y = 0.55 + sin(_t * 2.0) * 0.08
