extends Node3D
## Enemy projectile (wraith orb / warden volley). Moves in a straight line, swept-ray collision against
## world geometry and the player, so it can never pass through walls.

const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

var velocity := Vector3.ZERO
var damage := 10.0
var life := 4.0
var owner_enemy: Node = null
var _mesh: MeshInstance3D


static func spawn(parent: Node, from: Vector3, dir: Vector3, speed: float, dmg: float, col: Color, source: Node) -> Node3D:
	var p: Node3D = (load("res://scripts/world/projectile.gd") as GDScript).new()
	p.velocity = dir.normalized() * speed
	p.damage = dmg
	p.owner_enemy = source
	parent.add_child(p)
	p.global_position = from
	p._set_color(col)
	return p


func _ready() -> void:
	_mesh = MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.28
	sm.height = 0.56
	sm.radial_segments = 8
	sm.rings = 4
	_mesh.mesh = sm
	_mesh.material_override = Mats.glow(Color(0.5, 0.2, 0.9), 3.0)
	_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_mesh)
	AudioMgr.play_at("projectile", global_position, 40.0, -3.0)


func _set_color(col: Color) -> void:
	if _mesh == null:
		_ready()
	_mesh.material_override = Mats.glow(col, 3.0)
	Fx.emitter(self, Vector3.ZERO, Color(col.r, col.g, col.b, 0.8), 10, 0.5, 0.12, Vector3(0, 0.2, 0), 180.0)


func _physics_process(delta: float) -> void:
	life -= delta
	if life <= 0.0:
		queue_free()
		return
	var from := global_position
	var to := from + velocity * delta
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(from, to, 1 | 2)  # world + player
	var hit := space.intersect_ray(q)
	if hit.is_empty():
		global_position = to
		return
	var col: Object = hit.collider
	if col != null and col.has_method("take_damage"):
		col.take_damage(damage, from, owner_enemy)
	Fx.burst(get_parent(), hit.position, Color(0.7, 0.4, 1.0, 0.9), 10, 3.0, 0.4, 0.12, 2.0)
	queue_free()
